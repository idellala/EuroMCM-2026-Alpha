"""Release-interface tests: defaults, events, data safety, and public meaning."""
import csv
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'experiments'))
import run as public_entry
from common import reference_params,run,CFG,SCEN
from v4model import simulate
from outcomes_delivered import classify_arrays
import numpy as np

class ReleaseTests(unittest.TestCase):
    def test_direct_defaults_match_main_configuration(self):
        p=reference_params()
        direct=simulate(p,[0.,.5],*SCEN[2],T=2,h=.0125)
        explicit=run(p,[0.,.5],2,2,.0125)
        self.assertTrue(all(np.array_equal(direct.rec[k],explicit.rec[k]) for k in direct.rec))

    def test_public_label_does_not_assert_safety(self):
        p=reference_params()
        c=classify_arrays([0.,92.,100.],np.array([1.,.5,.02])*p['H0'],np.ones(3),dict(H0=p['H0'],H_ext=p['H_ext'],eta=.5,W=10,q_bar=.5))
        self.assertEqual(c['label'],'normal')
        self.assertEqual(public_entry.PUBLIC_LABELS[c['label']],'criterion_not_met')
        self.assertAlmostEqual(c['population_episodes'][0]['start'],92.)

    def test_shutdown_off_grid_actual_effect(self):
        tr=run(reference_params(),[0.],1,50,.0125,dict(kind='shutdown',tau=40.0001,success=True))
        at=np.flatnonzero(tr.t==40.0001)
        self.assertEqual(len(at),1)
        self.assertTrue(np.all(tr.rec['A_run'][at[0]:]==0))
        self.assertGreater(tr.rec['A_g'][at[0],0],0)

    def test_cli_metadata_and_overwrite_protection(self):
        with tempfile.TemporaryDirectory() as temp:
            dest=Path(temp)/'run'
            cmd=[sys.executable,'-B',str(ROOT/'run.py'),'simulate','--horizon','1','--output',str(dest)]
            first=subprocess.run(cmd,capture_output=True,text=True)
            self.assertEqual(first.returncode,0,first.stderr)
            receipt=json.loads((dest/'RUN.json').read_text())
            self.assertEqual(receipt['status'],'PASS')
            self.assertEqual(receipt['inputs']['main_configuration'],CFG)
            before=(dest/'summary.json').read_bytes()
            second=subprocess.run(cmd,capture_output=True,text=True)
            self.assertNotEqual(second.returncode,0)
            self.assertEqual(before,(dest/'summary.json').read_bytes())

    def test_invalid_alignment_and_step_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            for flag,value in [('--alignment','1.1'),('--tau-h','0'),('--step','nan')]:
                cmd=[sys.executable,'-B',str(ROOT/'run.py'),'simulate',flag,value,'--horizon','1','--output',str(Path(temp)/flag)]
                self.assertNotEqual(subprocess.run(cmd,capture_output=True).returncode,0)

    def test_parameter_snapshot_matches_executed_defaults(self):
        snapshot=json.loads((ROOT/'config/reference_parameters.json').read_text())
        actual=reference_params()
        self.assertEqual(set(snapshot),set(actual))
        for key,value in snapshot.items():
            self.assertTrue(math.isclose(value,actual[key],rel_tol=1e-14,abs_tol=0),key)

    def test_current_source_matches_release_registry(self):
        registry=ROOT/'config/RELEASE_SOURCES.json'
        if not registry.exists():self.fail('Missing release source registry')
        for name,digest in json.loads(registry.read_text()).items():
            self.assertEqual(public_entry.hash_file(ROOT/name),digest,name)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ReleaseTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    out=Path(os.environ['V4_TEST_OUTPUT'])
    out.mkdir(parents=True,exist_ok=True)
    if (out/'PUBLIC_INTERFACE_TESTS.json').exists():raise FileExistsError('Use a fresh test-report directory')
    (out/'PUBLIC_INTERFACE_TESTS.json').write_text(json.dumps(dict(status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors)),indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
