"""Independent migration and scientific interface tests; no old evidence is labelled as rerun."""
import importlib.metadata
import json
import math
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments'))
from common import CFG, SCEN, HGRID, PGRID, metrics, reference_params, run, sha
from v4model import grid_allocation
from joint_routing import joint_route
import numpy as np

def main():
    started=time.time(); checks=[]
    def check(name, test, detail=None):
        checks.append(dict(name=name,status='PASS' if bool(test) else 'FAIL',detail=detail))
        print(checks[-1]['status'],name,flush=True)
    manifest=json.loads((ROOT/'config/RELEASE_SOURCES.json').read_text())
    check('public_source_hashes',all(sha(ROOT/name)==digest for name,digest in manifest.items()),dict(files=len(manifest),scope='Current public sources; old migration evidence is not redistributed'))
    p=reference_params()
    rng=np.random.default_rng(20261018)
    D=rng.uniform(1,50000,20000); E=rng.uniform(0,100000,20000); a=rng.uniform(0,1,20000); A=rng.uniform(0,1e5,20000)
    P=a*np.minimum(E,D)
    for phi in (1.,np.inf):
        z=grid_allocation(A,E,P,D,np.inf,np.zeros(len(A),bool),phi)
        check('allocation_bounds_phi_'+str(phi),np.all(z>=0)&np.all(z<=A)&np.all(E-z>=P-1e-10))
    xg,xs=joint_route(np.array([10.,10.,10.,0.]),np.array([200.,9.,0.,0.]),np.array([0.,0.,10.,0.]),.1,20.)
    check('partial_self_build_without_grid',xg[1]==0 and 0<xs[1]<10)
    check('zero_land_and_zero_plan',xg[2]==xs[2]==xg[3]==xs[3]==0)
    xg,xs=joint_route(10.,.5,0.,.1,0.)
    check('zero_generation_footprint',float(xg)==0 and float(xs)==5)
    for s in SCEN:
        tr=run(dict(p,f=0.),[0.,1.],s,10.,.0125)
        check('no_RSI_s'+str(s),np.array_equal(tr.rec['H'],np.full_like(tr.rec['H'],p['H0'])) and np.all(tr.rec['q']==1))
    for s in (1,2):
        q=dict(p,mu=math.log(2)/HGRID[0],r_phys=p['delta_A']+math.log(2)/PGRID[0])
        tr=run(q,[0.,.5,.9,1.],s,100.,.00625); m=metrics(tr,q)
        saved=json.loads((ROOT/'results/current/stage4/results_T100.json').read_text())['rows'][str(s)]
        expected=[next(r for r in saved if r['tau_H']==float(HGRID[0]) and r['tau_phys']==float(PGRID[0]) and r['a']==a) for a in (0.,.5,.9)]
        if s==1:
            check('bitwise_imported_H_s1',all(m[j]['H_ratio_T']==r['H_ratio_T'] for j,r in enumerate(expected)))
        else:
            check('repaired_self_supply_saved_regression',all(abs(m[j]['H_ratio_T']-r['H_ratio_T'])<1e-11 for j,r in enumerate(expected)),dict(scope='Fresh repaired Python against delivered repaired rows; no obsolete model dependency'))
        check('population_identity_s'+str(s),max(r['population_identity_error'] for r in m)<1e-10)
        check('nonnegative_and_autonomy_s'+str(s),all(np.all(tr.rec[k]>=0) for k in ('H','A_g','A_s','E_H','L_H')) and np.all((tr.rec['I']>=0)&(tr.rec['I']<=1)))
        check('alignment_one_s'+str(s),m[-1]['H_ratio_T']==1.)
        bound=p['H0']*np.exp(-q['mu']*tr.t)
        check('population_lower_bound_s'+str(s),np.all(tr.rec['H']>=bound[:,None]*(1-1e-12)))
    q=dict(p,mu=math.log(2)/HGRID[0],r_phys=p['delta_A']+math.log(2)/PGRID[0])
    for s in (1,2):
        tr=run(q,[0.],s,100.,.0125,dict(kind='shutdown',tau=60.,success=True)); R=tr.rec; mask=tr.t>=60; i=np.flatnonzero(mask)[0]
        check('shutdown_operation_s'+str(s),np.all(R['A_run'][mask]==0))
        check('shutdown_retains_and_retires_stock_s'+str(s),all(np.allclose(R[k][mask,0],R[k][i,0]*np.exp(-p['delta_A']*(tr.t[mask]-60)),rtol=1e-10,atol=1e-12) for k in ('A_g','A_s')))
        check('shutdown_freezes_C_I_s'+str(s),all(np.ptp(R[k][mask,0])<1e-12 for k in ('C','I')))
    base=run(q,[0.],1,100.,.0125)
    failed=run(q,[0.],1,100.,.0125,dict(kind='shutdown',tau=60.,success=False))
    check('shutdown_failure_bitwise',all(np.array_equal(base.rec[k],failed.rec[k]) for k in base.rec))
    capped=run(q,[0.],1,100.,.0125,dict(kind='cap',tau=60.,cap=415.))
    check('cap_enforced',np.all(capped.rec['A_g_run'][capped.t>=60]<=415*(1+1e-9)))
    check('cap_population_identity',metrics(capped,q)[0]['population_identity_error']<1e-10)
    # Sufficient-condition evidence: q>=a and the implication, not grid rounding.
    total=0;bad=0;badq=0
    for T in (100,200):
        for ge in ('0','0.0256677'):
            rows=json.loads((ROOT/'results/current'/('stage4' if ge=='0' else 'stage22')/f'results_T{T}.json').read_text())['rows']
            for rs in rows.values():
                for r in rs:
                    total+=1;badq+=r['min_q']<r['a']-1e-10
                    sufficient=max(0.,1-r['tau_H']/(T-p['W']))
                    bad+=(r['a']>=sufficient and r['label']!='normal')
    check('sufficient_condition_saved_evidence',bad==badq==0,dict(rows=total,implication_failures=bad,q_floor_failures=badq,scope='reaggregated saved data, not dynamic reproduction'))
    # Proposition E checked on the real frozen allocator.
    D=rng.uniform(1,50000,20000);E=D*rng.uniform(1,300,20000);a=rng.uniform(0,1,20000);P=a*D;U=E-P;h=D-P
    z=grid_allocation(U,E,P,D,np.inf,np.zeros(len(D),bool),1.)
    err=float(np.max(abs(1-(E-z)/D-h*h/(D*(U+h)))))
    check('proposition_E_identity',err<1e-12,err)
    env={k:importlib.metadata.version(k) for k in ('numpy','scipy','matplotlib','pandas')}
    report=dict(checks=checks,seconds=time.time()-started,python=sys.version,dependencies=env)
    out=Path(__import__('os').environ['V4_TEST_OUTPUT']);out.mkdir(parents=True,exist_ok=True)
    if (out/'TEST_REPORT.json').exists():raise FileExistsError('Use a fresh test output directory')
    (out/'TEST_REPORT.json').write_text(json.dumps(report,indent=2))
    (out/'TEST_REPORT.md').write_text('# Actual execution results\n\n'+'\n'.join('- '+r['status']+': '+r['name'] for r in checks)+'\n\nFull Stage 5/6/7 production experiments and historical rerun: NOT RUN in this acceptance test.\n')
    # Never rewrite dependency pins while running tests.
    return 0 if all(r['status']=='PASS' for r in checks) else 1

if __name__=='__main__':sys.exit(main())
