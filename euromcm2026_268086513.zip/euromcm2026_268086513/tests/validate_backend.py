import json,math,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'experiments'))
from common import reference_params,run,metrics,write_json,sha,HGRID,PGRID
from fast_batch import jobs_run,decode
from v4model import simulate

cases=[]
for sc in (1,2,3,4):
 for phi in (1.,np.inf):
  for a in (0.,1.):cases.append([float(HGRID[0]),float(PGRID[0]),a,100.,.00625,sc,0,0.,1e100,phi,0.])
for sc in (1,2):
 for kind in (1,2):cases.append([10.,3.,0.,200.,.0125,sc,kind,50.,415.,1.,0.])
cases += [[1.,3.,.5,200.,.0125,2,0,0.,1e100,1.,0.], [10.,3.,0.,200.,.0125,1,0,0.,1e100,1.,math.log(1.026)]]
start=time.time();cpp=jobs_run(cases);out=[]
for i,z in enumerate(cases):
 th,tp,a,T,h,sc,kind,tau,cap,phi,ge=z;p=reference_params();p.update(mu=math.log(2)/th,r_phys=p['delta_A']+math.log(2)/tp,g_E=ge)
 pol=None if kind==0 else (dict(kind='cap',tau=tau,cap=cap) if kind==1 else dict(kind='shutdown',tau=tau,success=True))
 r=simulate(p,[a],*{1:('E1','grid'),2:('E1','self'),3:('E2','grid'),4:('E2','self')}[int(sc)],T=T,h=h,policy=pol,routing='joint',phi_E=phi,k_scope='all')
 m=metrics(r,p)[0];c=decode(cpp[i,1]);dh=abs(c['H_ratio_T']-m['H_ratio_T'])
 ds=max(abs(c[k]-r.rec[k][-1,0])/max(1,abs(r.rec[k][-1,0])) for k in ('A_g','A_s','C','I'))
 dt=0. if c['t_eta']==m['t_eta'] else (abs(c['t_eta']-m['t_eta']) if c['t_eta'] is not None and m['t_eta'] is not None else 1e100)
 passed=dh<1e-9 and ds<1e-8 and dt<1e-5 and c['label']==m['label']
 out.append(dict(case=[float(v) if np.isfinite(v) else 'inf' for v in z],pass_=passed,H_error=dh,state_scaled_error=ds,event_error=dt,cpp_label=c['label'],python_label=m['label']))
 print('PASS' if passed else 'FAIL','backend',i,'H_error',dh,'state',ds,flush=True)
report=dict(status='PASS' if all(x['pass_'] for x in out) else 'FAIL',cases=out,seconds=time.time()-start,
            model_sha256=sha(ROOT/'src/v4model.py'),backend_sha256=sha(ROOT/'experiments/batch_kernel.cpp'))
write_json(Path(__import__('os').environ['V4_TEST_OUTPUT'])/'BACKEND_VALIDATION.json',report)
if report['status']!='PASS':raise SystemExit(1)
