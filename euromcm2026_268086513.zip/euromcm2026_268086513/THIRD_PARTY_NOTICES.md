# Scope of the project license

MIT applies to the original project software and original project-authored text.
It does not grant rights over cited publications, the official contest statement,
external source data, or quotations retained in historical reference notes.
The delivered result tables and figures are project-generated simulation outputs;
their numerical provenance is retained. Citations and links identify external
inputs, and no third-party paper PDF is bundled.

NumPy, SciPy, Pandas and Matplotlib are dependencies, installed separately under
their own licenses. No dependency distribution or virtual environment is bundled.
AI tools assisted model discussion, implementation, checking and writing; this
repository does not substitute for the team's complete contest AI-use report.

## Workflow schematic excerpt

The team-authored workflow excerpt in `figures/source/workflow.tex` and generated schematic figures are provided for reviewer inspection; no extension of the software MIT licence to newly supplied paper assets is implied. Full paper sources and original paper-figure assets are not bundled.
