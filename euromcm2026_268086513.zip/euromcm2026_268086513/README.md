# What Remains for Us?
### Resource Allocation and Human Fate under RSI

**EuroMCM 2026 Problem alpha | Team 268086513 | Model V4 | Paper editing edition v8**

**中文上传说明：本文件夹里的内容就是准备上传GitHub的内容。** 不用再上传完整审计包、旧版本、原论文项目或开发日志。先创建公开仓库，再上传本文件夹内全部文件；仓库网址需另填比赛提交表单。此整理未创建远程仓库或push。每次运行都用新的输出目录。下文是英文复现说明，验证范围见 `VALIDATION.json`。

## Scope

This lean repository contains the accepted V4 model and the numerical inputs supporting the supplied final paper v8. Model equations, parameters, thresholds, random designs and saved results are unchanged. Repository edition: `4.0.1-paper-v8-lean.1`, packaged 2026-10-19. This is a conditional modelling study, not a prediction.

Historical development versions, long audit logs, duplicated plot exports and full paper LaTeX sources are deliberately excluded. They remain in the team's full archive. Small historical reference tables are retained because the historical reproduction command actually reads them.

## Install

Python 3.9--3.11; dependencies in `requirements.txt` (NumPy 2.0.2, SciPy 1.13.1, pandas 2.2.3, Matplotlib 3.9.4).

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Windows: activate `.venv\Scripts\activate`. Run commands from this repository root. Use **new output directories**: the runner rejects existing outputs and protects delivered results. Pure Python and plotting need no compiler. `backend` and full `reproduce` need a C++17 compiler (`clang++`, `g++`, or `CXX`). Local backend checks cover macOS; native Windows/Linux execution and remote CI are not claimed.

## Main commands

```sh
# One representative trajectory (S1); use --scenario 2 for self-supply
python run.py simulate --scenario 1 --alignment 0 --tau-h 10 --tau-phys 3 --horizon 100 --step 0.00625 --output runs/s1

# Read/reaggregate the delivered tables; does NOT rerun all trajectories
python run.py verify --output runs/saved_check

# Current-source scientific and public-interface checks
python run.py test --output runs/tests

# Historical numerical reproduction and reference-data comparison
python run.py history --output runs/history

# Replot all nine final-paper figures from delivered evidence
python run.py paper-figures --output runs/paper_figures

# Selected dynamics and paper-data checks; NOT a full parameter scan
python run.py paper-checks --output runs/paper_checks

# Compile and compare 22 Python/C++ cases
python run.py backend --output runs/backend
```

`simulate` writes `trajectory.csv`, `summary.json` and `RUN.json` with actual parameters and source hashes. Add `--policy cap --tau 0 --cap 415` for an enforced grid operating cap, or `--policy shutdown --tau 65` for a conditional successful shutdown; `--shutdown-fails` selects failure. Four scenarios: S1 E1/grid; S2 E1/self-supply; S3 E2/grid; S4 E2/self-supply.

`paper-figures` generates PDF/PNG/SVG and per-figure CSVs, with zero new experiment trajectories. Figures 1/2 are editable schematics; Figure 2 is a semantic reconstruction, not recovered original drawing code. `figures/source/workflow.tex` retains the workflow TikZ. `paper/FIGURE_REFERENCE.json` preserves the previously checked compiled figure numbers, not filenames guessed as numbering. Final-paper plots use the frozen paper inputs only, preventing accidental mixing of model revisions. The obsolete eight-figure collection is not shipped.

`paper-checks` integrates five representative 200-year trajectories and checks saved inputs and Atlas counts. `history` integrates 36 combinations plus 312 dense-grid cases; the historical 10:1 density contrast remains **not reproduced**. `test` uses the previously accepted portable current-result checks (31 scientific + 7 interface tests); pre-repair migration comparisons remain in the full archive, not in this lean test suite. No tolerance or numerical expectation was relaxed to make this package pass.

## Full reruns (larger; not needed just to inspect results)

```sh
python run.py reproduce --output runs/full
python supplements/response_form/run.py --output runs/response
```

`reproduce` executes the backend gate, policy experiments, alignment refinements, fixed-seed sampling, fixed/growing-grid scans and history. This entire workflow was **NOT RUN for lean packaging**. The response supplement is separately registered, not a new main model; it does not recalculate global alignment thresholds or shares for the quadratic response. Delivered results are immutable inputs, not proof that all experiments were rerun here.

## Where to look

| Path | Contents |
|---|---|
| `src/`, `experiments/`, `run.py` | Final model, historical code and experimental entry points |
| `config/` | Main configuration, checked parameter snapshot, current source registry |
| `results/current/` | Accepted numerical results for history, fates, alignment, policy, sampling and supply growth |
| `data/representative_trajectories.csv` | Saved representative time samples used by the paper plots |
| `scripts/`, `figures/source/` | Final-paper plotting and editable workflow source |
| `tests/` | Executable scientific, interface and backend checks |
| `supplements/response_form/` | Registered linear/quadratic response comparison and its code/data |
| `paper/PAPER_CODE_MAP.md`, `paper/FIGURE_MAP.csv` | Compact chapter/figure-to-code/data navigation |
| `docs/` | Model, sources and scientific limitations |
| `VALIDATION.json` | Actual lean-package checks and unexecuted scopes |

`reference_params()` in `src/v4model.py` is the executed parameter source. The JSON is a tested snapshot; editing JSON alone does not change the simulator. Main defaults: joint routing, phi_E=1, K scope=all, r_H=0, g_E=0. Units: people, TWh/year-equivalent capacity, km2 and years.

Stored `normal` means **criterion_not_met**, not safety or small loss. Report population and crossing time alongside labels. Scenario proportions and shutdown weights are not real future probabilities. Demographic response/autonomy and K screening are uncalibrated assumptions; severe self-supply results extrapolate to tens of today's grid scale. No population recovery, fixed per-capita needs and incomplete upstream constraints limit interpretation. See `docs/LIMITATIONS_CN.md`.

Project software retains MIT; external inputs keep their own terms. The workflow schematic excerpt does not expand the MIT software licence to paper assets. No official problem PDF or external article full text is included. AI assisted modelling, code, checking and writing; the team's submission AI-use report remains separate. Public repository submission rules: https://www.euromcm.org/instructions .
