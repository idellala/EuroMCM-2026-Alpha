"""V3 M1-M3 allocation, shared by every modern simulation (vectorized).

R2 is available ONLY as a static envelope. Inputs may be scalars or arrays.
"""
import numpy as np

def allocate(H,x,a,E,L,lambda_dc,e_n,ell_n,lambda_gen=20.,
             supply_mode='existing_grid',policy_cap=np.inf,validate=True,phi=np.inf):
    """phi: relative capture weight per unit claim of RSI vs humans on the pool left after the alignment floor.

    phi=inf reproduces the delivered priority rule exactly (same arithmetic path). For finite phi each pool is
    shared by weighted water-filling: RSI admissible = max(U-h, U*phi*claim/(phi*claim+h)), capped by its claim,
    where U is the unprotected pool and h = D - P the humans' remaining claim. Joint projection over both pools.
    """
    H,x,a,E,L,lam,en,ln,lg,cap,ph=np.broadcast_arrays(*[np.asarray(v,float) for v in
                 (H,x,a,E,L,lambda_dc,e_n,ell_n,lambda_gen,policy_cap,phi)])
    if validate:
        for name,v in zip(('H','x','a','E','L','lambda_dc','e_n','ell_n','lambda_gen'),(H,x,a,E,L,lam,en,ln,lg)):
            if np.any(~np.isfinite(v)) or np.any(v<0):raise ValueError(name+' must be finite and nonnegative')
        if np.any(a>1) or np.any(lam<=0) or np.any(en<=0) or np.any(ln<=0):raise ValueError('Invalid alignment or positive coefficient')
        if np.any(np.isnan(cap)) or np.any(cap<0):raise ValueError('Invalid policy cap')
        if np.any(np.isnan(ph)) or np.any(ph<=0):raise ValueError('phi must be positive (inf allowed)')
    Dem_E=en*H;Dem_L=ln*H
    PE=a*np.minimum(E,Dem_E);PL=a*np.minimum(L,Dem_L)
    KE=E-PE;KL=(L-PL)/lam
    if supply_mode=='existing_grid':
        KR=np.minimum(KE,KL)
        run=np.minimum(np.minimum(x,KR),cap)
        finite=np.isfinite(ph)
        if np.any(finite):
            f=np.where(finite,ph,1.)
            hE=np.maximum(Dem_E-PE,0.);hL=np.maximum(Dem_L-PL,0.)
            wE=f*x;wL=f*lam*x
            shareE=np.divide(KE*wE,wE+hE,out=np.zeros_like(x),where=(wE+hE)>0)
            shareL=np.divide((L-PL)*wL,wL+hL,out=np.zeros_like(x),where=(wL+hL)>0)
            AE=np.maximum(KE-hE,shareE);AL=np.maximum(L-PL-hL,shareL)/lam
            run=np.where(finite,np.minimum(np.minimum(np.minimum(x,np.minimum(AE,AL)),KR),cap),run)
        grid=run;own=np.zeros_like(run);LA=lam*run;total=E
    elif supply_mode=='self_supply_envelope':
        if np.any(np.isfinite(ph)):raise ValueError('finite phi is defined for existing_grid only')
        if np.any(lg<=0):raise ValueError('R2 requires positive lambda_gen')
        KR=np.where(lam*KE>=L-PL,KL,KE+(L-PL-lam*KE)/(lam+lg))
        run=np.minimum(np.minimum(x,KR),cap)
        grid=np.minimum(run,KE);own=run-grid
        LA=lam*run+lg*own;total=E+own
    else:raise ValueError('Unknown supply_mode')
    EH=E-grid;LH=L-LA
    # Absorb only negative roundoff from a tight product/division constraint.
    # Values beyond the 32-ULP accounting tolerance are errors, never clipped.
    for value,budget in ((EH,E),(LH,L)):
        if np.any(value < -32*np.finfo(float).eps*np.maximum(1.,budget)):
            raise ArithmeticError('Negative physical resource')
    EH=np.maximum(EH,0.);LH=np.maximum(LH,0.)
    return dict(A=run,E_H=EH,E_A=run,L_H=LH,L_A=LA,
                E=E,L=L,E_total=total,A_grid=grid,A_self=own,
                P_E=PE,P_L=PL,Dem_E=Dem_E,Dem_L=Dem_L,
                K_E=KE,K_L=KL,K_R=KR,
                electricity_balance=EH+run-total,land_balance=LH+LA-L,
                electricity_headroom=KE-grid,land_headroom=L-PL-LA)
