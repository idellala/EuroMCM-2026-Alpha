"""Historical test of the SHARED PART using the phi-copy allocate() unchanged plus the M4 deficit-response form.

Occupant N (Neanderthals) takes the 'human' slot of allocate(); newcomer M (modern humans) takes the claimant slot
with claim x = e_M * M. One food-energy pool E = Q = 1 (normalised); land is made non-binding. Alignment a = 0.
Both populations follow  dX/dt = X [ r - mu (1 - min(1, q)) ]  with q = intake / need (minimum need = need, rho = 1).
phi = (c_M/c_N) * (e_N/e_M); equal per-capita capture (c_M = c_N) gives phi = e_N/e_M. phi = inf is the delivered
priority rule. No parameter is fitted to coexistence times; mu and r are declared assumptions.
"""
import json, sys, itertools
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent / 'phi' / 'euromcm_modern'))
import numpy as np
from scipy.integrate import solve_ivp
from resource_allocation import allocate

E_N = 4500.                        # kcal/day, Stage 1 representative within official 3000-5000 (women) / 4000-7000 (men)
BANDS = {'Europe (Higham 2014)': (2600, 5400), 'France/N Spain (Djakovic 2022)': (1400, 2900)}


def shares(N, M, e_N, e_M, phi):
    d = allocate(N, e_M * M, 0., 1., 1e12, 1e-9, e_N, 1e-12, phi=phi, validate=False)
    return float(d['E_H']) / (e_N * N), float(d['A']) / (e_M * M)


def run(de, r, mu, phi_mode, max_step=5.):
    e_N, e_M = 1.0, 1.0 - de / E_N                            # needs in units of e_N
    phi = np.inf if phi_mode == 'priority' else e_N / e_M
    qstar = 1 - r / mu
    N0 = 1 / (e_N * qstar); M0 = N0 / 9                         # occupant at own equilibrium; newcomer share 10%

    def rhs(t, y):
        N, M = np.maximum(y, 1e-300)
        qN, qM = shares(N, M, e_N, e_M, phi)
        return [N * (r - mu * (1 - min(1., qN))), M * (r - mu * (1 - min(1., qM)))]
    ev = lambda t, y: y[1] / (y[0] + y[1]) - 0.9
    ev.terminal = True; ev.direction = 1
    sol = solve_ivp(rhs, (0, 1e5), [N0, M0], method='LSODA', events=ev, rtol=1e-9, atol=1e-14, max_step=max_step)
    T = float(sol.t_events[0][0]) if len(sol.t_events[0]) else None
    approx = np.log(81) * e_M / ((mu - r) * (de / E_N)) if phi_mode == 'equal_capture' else None
    return dict(phi_mode=phi_mode, phi=float(phi) if np.isfinite(phi) else 'inf', delta_e=de, r=r, mu=mu, T10_90=T,
                clock_approx=approx, in_band={k: (T is not None and lo <= T <= hi) for k, (lo, hi) in BANDS.items()},
                solver_status=int(sol.status))


def alone_equilibrium(e, r, mu):
    """Single population alone with the same module (no competitor): integrate to steady state."""
    def rhs(t, y):
        X = max(y[0], 1e-300); q = min(1., 1. / (e * X))
        return [X * (r - mu * (1 - q))]
    return float(solve_ivp(rhs, (0, 2e4), [0.5], method='LSODA', rtol=1e-11, atol=1e-14).y[0, -1])


if __name__ == '__main__':
    rows = [run(de, r, mu, mode) for mode, de, r, mu in itertools.product(('equal_capture', 'priority'), (100., 225., 350.),
                                                                            (0.001, 0.01), (1 / 37, 1 / 35, 1 / 21))]
    step_check = [run(225., r, 1 / 35, 'equal_capture', max_step=2.5) for r in (0.001, 0.01)]
    density = []
    for de, r in itertools.product((100., 225., 350.), (0.001, 0.01)):
        e_M = 1 - de / E_N
        KN, KM = alone_equilibrium(1., r, 1 / 35), alone_equilibrium(e_M, r, 1 / 35)
        density.append(dict(delta_e=de, r=r, K_M_over_K_N=KM / KN, analytic_e_N_over_e_M=1 / e_M))
    out = dict(module='phi-copy resource_allocation.allocate (unchanged) + M4 deficit response for both populations',
               assumptions=dict(E_N=E_N, a=0., land='non-binding', rho=1, mu='declared {1/37,1/35,1/21} (Stage 1 clock range)',
                                r='declared {0.001, 0.01}/yr (0.01 = forager growth proxy, Gurven-Kaplan via V3)',
                                capture='equal per-capita capture -> phi = e_N/e_M; priority -> phi = inf'),
               bands=BANDS, rows=rows, step_check_max_step_2p5=step_check, density_each_alone=density)
    Path(__file__).with_name('hominin_shared_test.json').write_text(json.dumps(out, indent=1))
    for x in rows + step_check:
        print(x['phi_mode'], x['delta_e'], x['r'], round(x['mu'], 5), 'T=', None if x['T10_90'] is None else round(x['T10_90'], 1),
              'approx=', None if x['clock_approx'] is None else round(x['clock_approx'], 1), x['in_band'])
    for d in density: print('alone', d)
