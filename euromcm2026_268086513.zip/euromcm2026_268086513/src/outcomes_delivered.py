"""Frozen F1–F3. Classify trajectories BEFORE any policy-branch weighting.

Threshold comparisons are strict. Values within 16 floating-point ulps of a
threshold are snapped to equality ONLY to suppress representation roundoff.
H is interpolated log-linearly; q is linear. Duplicate times encode jumps.
"""
import numpy as np

LABELS=('normal','marginal','quasi_extinction')

def snap(y,threshold):
    y=np.array(y,dtype=float,copy=True)
    tol=16*np.spacing(float(threshold))
    y[np.abs(y-threshold)<=tol]=threshold
    return y

def episodes(t,y,threshold,logarithmic=False):
    t=np.asarray(t,float);y=snap(y,threshold)
    below=y<threshold
    if logarithmic:
        # Zero H is handled by F1; this representation locates positive crossings.
        vals=np.log(np.maximum(y,np.finfo(float).tiny)/threshold)
    else:vals=y-threshold
    result=[];can_join=False
    for j in range(len(t)-1):
        dt=t[j+1]-t[j]
        if dt==0:
            can_join=can_join and bool(below[j]) and bool(below[j+1]);continue
        b0,b1=below[j],below[j+1]
        if not (b0 or b1):can_join=False;continue
        start,end=t[j],t[j+1]
        if b0!=b1:
            if not np.isfinite(vals[j]+vals[j+1]):can_join=False;continue
            cross=t[j]+dt*(-vals[j])/(vals[j+1]-vals[j])
            if b0:end=cross
            else:start=cross
        if end>start:
            if can_join and result and abs(start-result[-1]['end'])<=1e-10:
                result[-1]['end']=float(end)
            else:result.append({'start':float(start),'end':float(end)})
        can_join=bool(b1)
    for r in result:
        r['duration']=r['end']-r['start']
        r['recovered_at']=r['end'] if r['end']<t[-1] or not below[-1] else None
    return result

def classify_arrays(t,H,q_n,p):
    t=np.asarray(t,float);H=np.asarray(H,float);q_n=np.asarray(q_n,float)
    if t.ndim!=1 or len(t)<2 or H.shape!=t.shape or q_n.shape!=t.shape or np.any(~np.isfinite(t)) or np.any(~np.isfinite(H)) or np.any(H<0) or np.any(np.diff(t)<0) or np.any(~np.isfinite(q_n)&(H>0)) or np.any((q_n<0)|(q_n>1+1e-12)):raise ValueError('Invalid classifier trajectory')
    qevents=episodes(t,q_n,p['q_bar'])
    hevents=episodes(t,H,p['eta']*p['H0'],True)
    hits=np.flatnonzero(snap(H,p['H_ext'])<p['H_ext'])
    ext_time=None
    if len(hits):
        j=hits[0];ext_time=float(t[j])
        if j>0 and H[j-1]>=p['H_ext'] and H[j]>0:
            ext_time=float(t[j-1]+(t[j]-t[j-1])*np.log(p['H_ext']/H[j-1])/np.log(H[j]/H[j-1]))
    qualifying=[r for r in qevents+hevents if r['duration']+1e-10>=p['W']]
    entry=min((r['start']+p['W'] for r in qualifying),default=None)
    label='quasi_extinction' if len(hits) else 'marginal' if qualifying else 'normal'
    recovery=[r['recovered_at'] for r in qualifying if r['recovered_at'] is not None]
    final_q=bool(np.isfinite(q_n[-1]) and snap([q_n[-1]],p['q_bar'])[0]<p['q_bar'])
    final_h=bool(snap([H[-1]],p['eta']*p['H0'])[0]<p['eta']*p['H0'])
    # A last-ten-year trend is a warning, NOT a fourth fate or proof of future extinction.
    trend_start=t[-1]-min(10.,t[-1]-t[0])
    if H[-1]>0 and np.all(H>0) and t[-1]>trend_start:
        logH_start=np.interp(trend_start,t,np.log(H))
        slope=float((np.log(H[-1])-logH_start)/(t[-1]-trend_start))
    else:slope=None
    return {'label':label,'first_quasi_extinction':ext_time,'first_marginal_entry':entry,'q_n_episodes':qevents,'population_episodes':hevents,'q_n_max_episode':max((r['duration'] for r in qevents),default=0.),'population_max_episode':max((r['duration'] for r in hevents),default=0.),'marginal_episode_recovery_times':sorted(recovery),'final_resource_below':final_q,'final_population_below':final_h,'final_below_any':final_q or final_h,'terminal_log_population_slope':slope,'terminal_decline_warning':bool(slope is not None and slope<-1e-12)}

def classify(tr,p,index=None):
    H=tr.state[:,0] if index is None else tr.state[:,index,0]
    q=tr.d['q_n'] if index is None else tr.d['q_n'][:,index]
    return classify_arrays(tr.t,H,q,p)
