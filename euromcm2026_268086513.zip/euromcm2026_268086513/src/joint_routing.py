"""Joint routing of the autonomous channel under land (diagnostic under priority allocation).

Variables per step: x_g (autonomous capacity built as grid facilities), x_s (built as self-powered facilities).
    x_g + x_s <= Q,   x_g <= K,   lam_dc*x_g + lam_s*x_s <= B,   x_g, x_s >= 0,   lam_s = lam_dc + lam_gen.
Lexicographic objective: (1) maximise x_g + x_s; (2) among those, maximise x_s.
K is ONLY a screening condition for autonomous grid fallback (user decision 2026-10-17), not a general grid limit.

Closed form (lam_dc > 0, lam_gen > 0). Let x_min = max(0, (lam_s*Q - B)/lam_gen): the least grid share that lets the
full Q fit on the land.
  (i)  if x_min <= min(Q, K): the full Q is buildable; x_g = x_min, x_s = Q - x_g  (largest x_s with total Q).
  (ii) otherwise total < Q. Total(x_g) = x_g + (B - lam_dc*x_g)/lam_s is strictly increasing in x_g (lam_dc < lam_s),
       so x_g = min(K, Q, B/lam_dc) and x_s = max(0, (B - lam_dc*x_g)/lam_s). This is unique.
The earlier draft omitted the 'x_min <= Q' condition (needed when B < lam_dc*Q) and could return x_s < 0.
lam_gen = 0: both routes need lam_dc per unit, so the land-limited total is min(Q, B/lam_dc) either way and the
self-supply preference gives x_s = min(Q, B/lam_dc), x_g = 0.
"""
import numpy as np


def joint_route(Q, B, K, lam_dc, lam_gen):
    Q, B, K, lam_dc, lam_gen = np.broadcast_arrays(*[np.asarray(v, float) for v in (Q, B, K, lam_dc, lam_gen)])
    if np.any(Q < 0) or np.any(B < 0) or np.any(K < 0) or np.any(lam_dc <= 0) or np.any(lam_gen < 0):
        raise ValueError('require Q,B,K >= 0, lam_dc > 0, lam_gen >= 0')
    lam_s = lam_dc + lam_gen
    pos = lam_gen > 0
    safe_gen = np.where(pos, lam_gen, 1.)
    x_min = np.where(pos, np.maximum(0., (lam_s * Q - B) / safe_gen), 0.)
    full = pos & (x_min <= np.minimum(Q, K))
    xg_full = x_min
    xg_part = np.minimum(np.minimum(K, Q), B / lam_dc)
    xs_part = np.maximum(0., (B - lam_dc * xg_part) / lam_s)
    xg = np.where(full, xg_full, xg_part)
    xs = np.where(full, Q - xg_full, xs_part)
    # lam_gen = 0 branch
    xs0 = np.minimum(Q, B / lam_dc)
    xg = np.where(pos, xg, 0.)
    xs = np.where(pos, xs, xs0)
    # case (i) with x_min == 0 returns x_g = 0 exactly, x_s = Q exactly (no rounding when land is sufficient)
    return xg, xs
