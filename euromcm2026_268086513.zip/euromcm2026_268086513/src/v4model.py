"""V4 resource-competition model, with the accepted P0 numerical repair.

States: H (people), A_g/A_s (TWh/year equivalent installed capacity), C and I.
Installed capacity occupies land; running capacity consumes electricity.
The public defaults are the registered main configuration: joint routing,
proportional electricity sharing (phi_E=1), K screening on every grid build.
All rates use step-start states; frozen legacy defaults are archived separately.
"""
import math
from dataclasses import dataclass, field
import numpy as np
from joint_routing import joint_route

EVENT_ATOL = 1e-12
LN2 = math.log(2)


def reference_params():
    H0, E0, L0, A_ref, lam_ref, delta = 8.2e9, 31256., 47810000., 41.5, .1, .1
    e_n = (E0 - A_ref) / H0
    eps = .20
    return dict(
        H0=H0, E0_ref=E0, L0_ref=L0, E0_avail=E0, L0_avail=L0, A_ref=A_ref,
        e_n=e_n, ell_n=(L0 - lam_ref * A_ref) / H0,
        eps=eps, F=(1 - eps) / eps * e_n * H0,          # fixed non-electric supply (E2 only), reference account
        mu=LN2 / 50, r_H=0., chi=.1,
        lambda_dc=.1, lambda_gen=20., L_other=0.,
        f=.1, C_max=10., delta_A=delta, r_A0=delta + math.log(1.12),
        G_hw=.1 * (945 - 415) / 6 + delta * A_ref, r_phys=delta + LN2 / 10,
        g=LN2 / 10, kappa=LN2 / 30,
        H_ext=1e4, eta=.5, W=10., T=100., h=.0125,
        g_E=0.,   # spec §13: exogenous growth rate of human grid supply (0 = main configuration, fixed grid)
    )


@dataclass
class Run:
    t: np.ndarray
    rec: dict
    meta: dict = field(default_factory=dict)


FIELDS = ('H', 'A_g', 'A_s', 'C', 'I', 'E', 'E_H', 'A_g_run', 'A_run', 'Lam', 'Lam_L', 'L_H', 'q_E', 'q_L', 'q',
          'q_is_L', 'idle_frac', 'G_h', 'G_a', 'G_h_cap', 'G_a_cap', 'G_des', 'land_limited', 'P_E', 'P_L', 'D_E')



def grid_allocation(Ag, E, PE, DE, Kpol, shut, phi_E):
    """Electricity to grid-connected RSI capacity. phi_E = inf: priority (round-1 arithmetic, bitwise).
    Finite phi_E (spec §11.2): claim = installed A_g incl. idle (0 if shut); human claim h = D_E - P_E;
    run* = min(x, max(U - h, U*phi*x/(phi*x + h))), U = E - P_E; then the policy cap."""
    if np.isinf(phi_E):
        return np.where(shut, 0., np.minimum(np.minimum(Ag, E - PE), Kpol))
    xc = np.where(shut, 0., Ag); hE = np.maximum(DE - PE, 0.); U = E - PE; wc = phi_E * xc
    share = np.divide(U * wc, wc + hE, out=np.zeros_like(np.asarray(U * wc, float)), where=(wc + hE) > 0)
    return np.where(shut, 0., np.minimum(np.minimum(xc, np.maximum(U - hE, share)), Kpol))


def simulate(p, a, energy='E1', supply='grid', policy=None, T=None, h=None, routing='joint', phi_E=1., k_scope='all'):
    """a may be a scalar or 1-D array (vectorised over alignment). policy: None, {'kind':'cap','tau','cap'} or
    {'kind':'shutdown','tau','success':bool}."""
    if energy not in ('E1', 'E2') or supply not in ('grid', 'self'):
        raise ValueError('unknown structural switch')
    if routing not in ('forced', 'fallback', 'fallback_whole', 'joint'):
        raise ValueError('unknown routing rule')
    if not (phi_E > 0) or np.isnan(phi_E):
        raise ValueError('phi_E must be positive (inf = priority)')
    if k_scope not in ('autonomous', 'all') or (k_scope == 'all' and routing != 'joint'):
        raise ValueError("k_scope must be 'autonomous' or 'all'; 'all' requires routing='joint'")
    T = p['T'] if T is None else T
    h = p['h'] if h is None else h
    a = np.atleast_1d(np.asarray(a, float))
    if np.any((a < 0) | (a > 1)):
        raise ValueError('a outside [0,1]')
    n_steps = int(round(T / h))
    if abs(n_steps * h - T) > 1e-9:
        raise ValueError('T must be a multiple of h')
    tau = None if policy is None else float(policy['tau'])
    grid = np.arange(n_steps + 1) * h
    if tau is not None:
        nearest = int(np.argmin(np.abs(grid - tau)))
        if np.isclose(grid[nearest], tau, rtol=0., atol=EVENT_ATOL):
            tau = float(grid[nearest])  # one absolute-tolerance convention, including endpoints
        elif 0 < tau < T:
            grid = np.sort(np.r_[grid, tau])
    n = len(a)
    H = np.full(n, p['H0']); Ag = np.full(n, p['f'] * 415.); As = np.zeros(n)
    C = np.ones(n); I = np.zeros(n); shut = np.zeros(n, bool)
    rec = {k: np.empty((len(grid), n)) for k in FIELDS}
    fallback_used = np.zeros((len(grid), n))
    BK = {k_: np.zeros((len(grid), n)) for k_ in ('planned_total', 'planned_auto', 'built_grid', 'built_self', 'built_auto_grid', 'unrealised', 'land_available', 'land_used', 'grid_room_K')}
    decay_factor = lambda dt: (-math.expm1(-p['delta_A'] * dt)) / p['delta_A']
    max_res = 0.

    def diag(t, H, Ag, As, C, I, shut):
        SH = np.minimum(1., H / (p['chi'] * p['H0']))
        E = p['E0_avail'] * math.exp(p['g_E'] * t) * (I + (1 - I) * SH)   # spec §13; exp(0) = 1.0 keeps g_E = 0 bitwise
        L = p['L0_avail']
        DE = p['e_n'] * H; DL = p['ell_n'] * H
        PE = a * np.minimum(E, DE); PL = a * np.minimum(L, DL)
        cap_active = policy is not None and policy['kind'] == 'cap' and t >= tau - 1e-12
        Kpol = policy['cap'] if cap_active else np.inf
        Ag_run = grid_allocation(Ag, E, PE, DE, Kpol, shut, phi_E)
        EH = E - Ag_run
        # At tiny H, E - A_run can round to zero despite a positive protected floor.
        # Correct only loss of the known floor within 32 ulps of the power account.
        energy_tol = 32 * np.spacing(np.asarray(E, float))
        if np.any(PE - EH > energy_tol):
            raise FloatingPointError('electricity floor violated beyond account roundoff')
        EH = np.where(EH < PE, PE, EH)
        lam_s = p['lambda_dc'] + p['lambda_gen']
        Lam = p['lambda_dc'] * Ag + lam_s * As
        LamL = np.maximum(0., Lam - p['L_other'])
        LH = L - LamL
        # Absorb only account roundoff at the protected land boundary (32 ulps).
        # Keep the protected amount explicit to avoid cancellation for tiny H.
        land_tol = 32 * np.spacing(float(L))
        tight_land = np.abs((L - PL) - LamL) <= land_tol
        LH = np.where(tight_land, PL, LH)
        LamL = np.where(tight_land, L - LH, LamL)
        Arun = np.where(shut, 0., Ag_run + As)
        with np.errstate(divide='ignore', invalid='ignore'):
            qE = np.where(H > 0, (EH / DE) if energy == 'E1' else (EH + p['F']) / (DE / p['eps']), np.nan)
            qL = np.where(H > 0, LH / DL, np.nan)
        q = np.minimum(1., np.minimum(qE, qL))
        Gh_cap = (1 - I) * SH * p['G_hw']
        Ga_cap = I * p['r_phys'] * Arun
        Gdes = p['r_A0'] * C * Arun
        tot = Gh_cap + Ga_cap
        s = np.where(tot > Gdes, np.divide(Gdes, tot, out=np.zeros_like(tot), where=tot > 0), 1.)
        Gh = np.where(shut, 0., s * Gh_cap); Ga = np.where(shut, 0., s * Ga_cap)
        return dict(SH=SH, E=E, L=L, DE=DE, DL=DL, PE=PE, PL=PL, Ag_run=Ag_run, EH=EH, Lam=Lam, LamL=LamL, LH=LH,
                    Arun=Arun, qE=qE, qL=qL, q=q, Gh=Gh, Ga=Ga, Gh_cap=Gh_cap, Ga_cap=Ga_cap, Gdes=Gdes)

    def record(k, t, d, land_limited):
        nonlocal max_res
        vals = dict(H=H, A_g=Ag, A_s=As, C=C, I=I, E=d['E'], E_H=d['EH'], A_g_run=d['Ag_run'], A_run=d['Arun'],
                    Lam=d['Lam'], Lam_L=d['LamL'], L_H=d['LH'], q_E=d['qE'], q_L=d['qL'], q=d['q'],
                    q_is_L=(d['qL'] <= d['qE']) & (d['q'] < 1), idle_frac=np.where(Ag > 0, 1 - d['Ag_run'] / np.maximum(Ag, 1e-300), 0.),
                    G_h=d['Gh'], G_a=d['Ga'], G_h_cap=d['Gh_cap'], G_a_cap=d['Ga_cap'], G_des=d['Gdes'],
                    land_limited=land_limited, P_E=d['PE'], P_L=d['PL'], D_E=d['DE'])
        for f_ in FIELDS: rec[f_][k] = vals[f_]
        # conservation and physical bounds (raise, never clip)
        res = max(float(np.max(np.abs(d['EH'] + d['Ag_run'] - d['E']))), float(np.max(np.abs(d['LH'] + d['LamL'] - d['L']))) / 1e3)
        max_res = max(max_res, res)
        for name, v in (('H', H), ('A_g', Ag), ('A_s', As), ('E_H', d['EH']), ('L_H', d['LH'])):
            if np.any(~np.isfinite(v)) or np.any(v < -1e-9 * max(1., float(np.max(np.abs(v))))):
                raise FloatingPointError(f'invalid {name} at t={t}')
        if np.any(d['Ag_run'] > Ag * (1 + 1e-12) + 1e-12): raise FloatingPointError('running exceeds installed')
        if np.any(d['Gh'] > d['Gh_cap'] * (1 + 1e-12) + 1e-15) or np.any(d['Ga'] > d['Ga_cap'] * (1 + 1e-12) + 1e-15):
            raise FloatingPointError('channel above its capacity')
        if np.any(d['Gh'] + d['Ga'] > d['Gdes'] * (1 + 1e-12) + 1e-12) and not np.all(shut):
            raise FloatingPointError('construction above desired total')

    if policy is not None and policy['kind'] == 'shutdown' and tau == 0 and policy['success']:
        shut = np.ones(n, bool)
    d = diag(0., H, Ag, As, C, I, shut)
    record(0, 0., d, np.zeros(n, bool))
    for k in range(1, len(grid)):
        t0, t1 = grid[k - 1], grid[k]; dt = t1 - t0
        d = diag(t0, H, Ag, As, C, I, shut)
        # population
        Hn = H * np.exp((p['r_H'] - p['mu'] * (1 - np.nan_to_num(d['q'], nan=1.))) * dt)
        # capability and autonomy (frozen automatically when A_run = 0)
        w = np.minimum(1., d['Arun'] / p['A_ref'])
        Cn = p['C_max'] / (1 + (p['C_max'] / C - 1) * np.exp(-p['g'] * w * dt))
        In = 1 - (1 - I) * np.exp(-p['kappa'] * w * C * dt)
        # construction routed by supply switch, then limited by buildable land
        fac = decay_factor(dt)
        if supply == 'grid':
            dAg = (d['Gh'] + d['Ga']) * fac; dAs = np.zeros(n)
        else:
            dAg = d['Gh'] * fac; dAs = d['Ga'] * fac
        # Numerical repair: retired land is available to this step's replacement construction.
        # Protected floor uses the same step-start state; no physical parameter changes.
        decay = math.exp(-p['delta_A'] * dt)
        retired_Lam = d['Lam'] * decay
        retired_LamL = np.maximum(0., retired_Lam - p['L_other'])
        avail = np.maximum(0., p['L_other'] - np.minimum(retired_Lam, p['L_other'])) + np.maximum(0., d['L'] - d['PL'] - retired_LamL)
        fb = np.zeros(n)
        x_ag = np.zeros(n); Kroom = np.zeros(n)
        if supply == 'self' and routing == 'joint':
            # Registered joint-routing rule: human-supply-chain channel (grid facilities) takes land first
            # (recorded assumption); then the autonomous channel solves the lexicographic two-route problem.
            need_h = p['lambda_dc'] * dAg
            sc_h = np.where(need_h > avail * (1 + 1e-12), np.divide(avail, need_h, out=np.zeros_like(need_h), where=need_h > 0), 1.)
            dAg_r = sc_h * dAg
            Kp = policy['cap'] if (policy is not None and policy['kind'] == 'cap' and t0 >= tau - 1e-12) else np.inf
            if k_scope == 'all':   # D-1(b): the screening applies to every grid-facility build (behavioural rule)
                dAg_r = np.minimum(dAg_r, np.maximum(0., np.minimum(d['E'] - d['PE'], Kp) - Ag * decay))
            B_left = np.maximum(0., avail - p['lambda_dc'] * dAg_r)
            Kroom = np.maximum(0., np.minimum(d['E'] - d['PE'], Kp) - Ag * decay - dAg_r)
            x_ag, dAs_r = joint_route(dAs, B_left, Kroom, p['lambda_dc'], p['lambda_gen'])
            fb = x_ag
            land_limited = (sc_h < 1) | (x_ag + dAs_r < dAs * (1 - 1e-12))
        elif supply == 'grid' and routing == 'joint' and k_scope == 'all':
            # grid-only scenario under D-1(b): unchanged land rule (proportional), then the same screening on the total
            need = p['lambda_dc'] * dAg
            land_limited = need > avail * (1 + 1e-12)
            sc = np.where(land_limited, np.divide(avail, need, out=np.zeros_like(need), where=need > 0), 1.)
            Kp = policy['cap'] if (policy is not None and policy['kind'] == 'cap' and t0 >= tau - 1e-12) else np.inf
            Kroom = np.maximum(0., np.minimum(d['E'] - d['PE'], Kp) - Ag * decay)
            dAg_r = np.minimum(sc * dAg, Kroom); dAs_r = np.zeros(n)
        elif supply == 'self' and routing == 'fallback_whole':
            # DIAGNOSTIC ONLY (not adopted): if the self-powered plan cannot be built in full on the land left after
            # the human-channel grid plan, the whole autonomous plan is offered to grid facilities instead.
            need_h = p['lambda_dc'] * dAg
            sc_h = np.where(need_h > avail * (1 + 1e-12), np.divide(avail, need_h, out=np.zeros_like(need_h), where=need_h > 0), 1.)
            left = np.maximum(0., avail - sc_h * need_h)
            self_ok = (p['lambda_dc'] + p['lambda_gen']) * dAs <= left * (1 + 1e-12)
            dAs_r = np.where(self_ok, dAs, 0.); left2 = left - np.where(self_ok, (p['lambda_dc'] + p['lambda_gen']) * dAs, 0.)
            dAg_r = sc_h * dAg
            Kp = policy['cap'] if (policy is not None and policy['kind'] == 'cap' and t0 >= tau - 1e-12) else np.inf
            grid_space = np.maximum(0., np.minimum(d['E'] - d['PE'], Kp) - Ag * decay - dAg_r)
            fb = np.where(self_ok, 0., np.minimum(np.minimum(dAs, grid_space), np.maximum(0., left2) / p['lambda_dc']))
            land_limited = (sc_h < 1) | ~self_ok
        else:
            need = p['lambda_dc'] * dAg + (p['lambda_dc'] + p['lambda_gen']) * dAs
            land_limited = need > avail * (1 + 1e-12)
            sc = np.where(land_limited, np.divide(avail, need, out=np.zeros_like(need), where=need > 0), 1.)
            dAg_r = sc * dAg; dAs_r = sc * dAs
            if supply == 'self' and routing == 'fallback':
                # Adopted rule (user, 2026-10-17): self-build keeps priority; only autonomous capacity left unrealised by
                # land may turn to grid facilities, limited by grid space net of existing installed (incl. idle) and of
                # this step's other grid plans, by remaining campus land, by the human floors (built into E-P_E and
                # L-P_L) and by the unused autonomous capacity itself. Nothing unbuilt is carried over.
                unrealised = dAs - dAs_r
                land_left = np.maximum(0., avail - sc * need)
                Kp = policy['cap'] if (policy is not None and policy['kind'] == 'cap' and t0 >= tau - 1e-12) else np.inf
                grid_space = np.maximum(0., np.minimum(d['E'] - d['PE'], Kp) - Ag * decay - dAg_r)
                fb = np.minimum(np.minimum(unrealised, grid_space), land_left / p['lambda_dc'])
        fb = np.where(shut, 0., fb)
        fallback_used[k] = fb
        BK['planned_total'][k] = dAg + dAs; BK['planned_auto'][k] = dAs if supply == 'self' else d['Ga'] * fac
        BK['built_grid'][k] = dAg_r + fb; BK['built_self'][k] = dAs_r; BK['built_auto_grid'][k] = fb
        BK['unrealised'][k] = (dAg + dAs) - (dAg_r + fb + dAs_r)
        BK['land_available'][k] = avail; BK['grid_room_K'][k] = Kroom
        BK['land_used'][k] = p['lambda_dc'] * (dAg_r + fb) + (p['lambda_dc'] + p['lambda_gen']) * dAs_r
        Ag = Ag * decay + dAg_r + fb
        As = As * decay + dAs_r
        H, C, I = Hn, Cn, In
        # policy event at t1
        if policy is not None and policy['kind'] == 'shutdown' and abs(t1 - tau) <= EVENT_ATOL and policy['success']:
            shut = np.ones(n, bool)
        d1 = diag(t1, H, Ag, As, C, I, shut)
        record(k, t1, d1, land_limited)
    rec['fallback'] = fallback_used
    rec.update(BK)
    return Run(grid, rec, dict(a=a, energy=energy, supply=supply, h=h, T=T, routing=routing, max_conservation_residual=max_res))
