# Registered response-form supplement

This is a structural comparison, not a replacement main model. Numerical model
files and saved result tables are unchanged. The runner adapts only input/output
paths and the integrity-check target for a portable checkout. The original dated
registration and its hashes are retained. Runner hashes differ from the earlier
local execution; model hashes do not.

```sh
python supplements/response_form/run.py --output runs/response_form
```

The registered 16 designs, two response functions and two steps produce 64 main
trajectories to year 200, reporting years 100 and 200, with local refinement only
when the registered screen triggers. Uses four worker processes. Do not reuse an
existing output directory. Historical Mac-only paths/logs are not redistributed.

The saved tables under `results/` are prior actual runs. A fresh run writes its own
timing and checks. The constant zero-growth no-RSI baseline and the original fate
classifier remain unchanged. Uncertainty here is structural, not sampling noise.
