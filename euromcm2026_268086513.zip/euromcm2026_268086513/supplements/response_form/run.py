"""Execute the preregistered, limited structural comparison. No frozen writes."""
import concurrent.futures, csv, datetime, hashlib, json, math, os, platform, sys, time
from pathlib import Path
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
sys.dont_write_bytecode=True
import numpy as np
SOURCE_ROOT=Path(__file__).resolve().parent
REPO=SOURCE_ROOT.parents[1]
if '--output' not in sys.argv:
    raise SystemExit('Usage: python supplements/response_form/run.py --output NEW_DIRECTORY')
ROOT=Path(sys.argv[sys.argv.index('--output')+1]).resolve()
sys.path.insert(0,str(SOURCE_ROOT/'model_copy'))
import v4model as baseline
import v4model_response as variant
from outcomes_delivered import classify_arrays

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def putjson(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def putcsv(p,rows):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with p.open('x',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def params(reg):
    p=baseline.reference_params();p['mu']=math.log(2)/reg['tau_H'];p['r_phys']=p['delta_A']+math.log(2)/reg['tau_phys'];return p
def policy(d):
    if d['kind']=='none':return None
    return dict(kind='cap',tau=d['tau'],cap=d['cap']) if d['kind']=='cap' else dict(kind='shutdown',tau=d['tau'],success=True)

def metrics(tr,p,j,T,shape):
    n=int(np.searchsorted(tr.t,T,side='right'))
    t=tr.t[:n];R=tr.rec;H=R['H'][:n,j];q=R['q'][:n,j]
    assert abs(t[-1]-T)<1e-10
    c=classify_arrays(t,H,np.ones_like(t),dict(H0=p['H0'],H_ext=p['H_ext'],eta=p['eta'],W=p['W'],q_bar=.5))
    deficit=1-q[:-1];power=1 if shape=='linear' else 2
    raw=float(np.sum(deficit*np.diff(t)));effective=float(np.sum(deficit**power*np.diff(t)))
    energy_res=float(np.max(np.abs(R['E_H'][:n,j]+R['A_g_run'][:n,j]-R['E'][:n,j])))
    land_res=float(np.max(np.abs(R['L_H'][:n,j]+R['Lam_L'][:n,j]-p['L0_avail'])))
    return dict(T=T,H_ratio_T=float(H[-1]/p['H0']),H_T=float(H[-1]),deficit_people=float(p['H0']-H[-1]),label=c['label'],label_CN={'normal':'未达持续/准灭绝判据','marginal':'达到边缘人口判据','quasi_extinction':'达到准灭绝判据'}[c['label']],first_half_crossing=c['population_episodes'][0]['start'] if c['population_episodes'] else None,first_marginal_entry=c['first_marginal_entry'],first_quasi_extinction=c['first_quasi_extinction'],below_half_at_T=bool(H[-1]<p['eta']*p['H0']),min_q=float(np.min(q)),q_T=float(q[-1]),raw_deficit_years=raw,effective_response_years=effective,population_identity_error=float(abs(math.log(H[-1]/p['H0'])-p['r_H']*T+p['mu']*effective)),max_m_run=float(np.max(R['A_run'][:n,j])/p['E0_ref']),max_m_installed=float(np.max(R['A_g'][:n,j]+R['A_s'][:n,j])/p['E0_ref']),energy_balance_residual_TWh_per_yr=energy_res,land_balance_residual_km2=land_res,protected_energy_floor_min=float(np.min(R['E_H'][:n,j]-R['P_E'][:n,j])),protected_land_floor_min=float(np.min(R['L_H'][:n,j]-R['P_L'][:n,j])))

def execute_job(job):
    reg,designs,shape,h,stage=job
    started=now();tic=time.perf_counter();p=params(reg)
    sc=designs[0]['scenario'];pol=policy(designs[0]);a=[d['a'] for d in designs]
    tr=variant.simulate(p,a,'E1','grid' if sc==1 else 'self',policy=pol,T=200.,h=h,response_shape=shape,**{k:v for k,v in reg['config'].items() if k not in ('g_E','r_H')})
    out=[];samples=[]
    for j,d in enumerate(designs):
        for T in reg['horizons']:
            out.append(dict(case_id=d['id'],scenario=sc,a=d['a'],kind=d['kind'],tau=d['tau'],cap=d['cap'],shape=shape,h=h,run_stage=stage,**metrics(tr,p,j,T,shape)))
        take=np.unique(np.r_[np.searchsorted(tr.t,np.arange(0,201)),np.searchsorted(tr.t,[d['tau'] or 0])])
        for k in take:
            samples.append(dict(case_id=d['id'],shape=shape,h=h,t=float(tr.t[k]),**{f:float(tr.rec[f][k,j]) for f in ('H','A_g','A_s','A_run','C','I','q','q_E','q_L','E','E_H','L_H')}))
        # No instantaneous change in I at shutdown: the baseline value at tau is I(tau-).
        for r in out:
            if r['case_id']==d['id']:
                r['I_at_event']=float(tr.rec['I'][np.searchsorted(tr.t,d['tau']),j]) if d['tau'] is not None else None
    stem=f"{designs[0]['id']}_{shape}_h{h:g}_{stage}"
    putcsv(ROOT/'trajectory_samples'/(stem+'.csv'),samples)
    putjson(ROOT/'job_records'/(stem+'.json'),dict(started_at=started,finished_at=now(),wall_seconds=time.perf_counter()-tic,designs=designs,shape=shape,h=h,stage=stage,metrics=out,meta_max_conservation_residual=tr.meta['max_conservation_residual'],sample_note='annual samples plus policy event; all metrics calculated from full-step trajectories',full_step_count=len(tr.t)))
    return out,dict(job=stem,started_at=started,finished_at=now(),seconds=time.perf_counter()-tic,lanes=len(designs))

def auxiliary_tests(reg):
    checks=[];p=params(reg);cfg=dict(routing='joint',phi_E=1.,k_scope='all')
    def check(name,value,detail=None):
        checks.append(dict(name=name,status='PASS' if value else 'FAIL',detail=detail));assert value,name
    x=np.linspace(0,1,1001)
    check('response_endpoints_and_monotonicity',bool(x[0]**2==0 and x[-1]**2==1 and np.all(np.diff(x*x)>=0)))
    src=SOURCE_ROOT/'model_copy'
    check('copied_original_source_sha_matches_frozen',sha(src/'v4model.py')==sha(REPO/'src/v4model.py'))
    # The permitted implementation change is inspected by the supplied source diff.
    for sc in [1,2]:
        supply='grid' if sc==1 else 'self'
        a=baseline.simulate(p,0.,'E1',supply,T=100.,h=.0125,**cfg)
        b=variant.simulate(p,0.,'E1',supply,T=100.,h=.0125,response_shape='linear',**cfg)
        check(f'linear_full_state_bitwise_S{sc}',bool(np.array_equal(a.t,b.t) and all(np.array_equal(a.rec[k],b.rec[k],equal_nan=True) for k in a.rec)))
    for shape in reg['shapes']:
        pn=dict(p,f=0.)
        tr=variant.simulate(pn,0.,'E1','grid',T=2.,h=.0125,response_shape=shape,**cfg)
        check('no_RSI_constant_baseline_'+shape,bool(np.all(tr.rec['H']==p['H0']) and np.all(tr.rec['q']==1)))
        tr=variant.simulate(p,1.,'E1','self',T=2.,h=.0125,response_shape=shape,**cfg)
        check('full_alignment_boundary_'+shape,bool(np.all(tr.rec['H']==p['H0']) and np.min(tr.rec['q'])>=1-1e-14))
    a=variant.simulate(p,0.,'E1','grid',T=70.,h=.0125,response_shape='quadratic',**cfg)
    b=variant.simulate(p,0.,'E1','grid',policy=dict(kind='shutdown',tau=40.,success=False),T=70.,h=.0125,response_shape='quadratic',**cfg)
    check('shutdown_failure_equals_baseline_representative',all(np.array_equal(a.rec[k],b.rec[k],equal_nan=True) for k in a.rec))
    return checks

def convergence(rows):
    keys={ (r['case_id'],r['shape'],r['T']) for r in rows}
    result=[];refine=set()
    for key in sorted(keys):
        candidates=[r for r in rows if (r['case_id'],r['shape'],r['T'])==key]
        co=next(r for r in candidates if r['h']==.0125);fi=next(r for r in candidates if r['h']==.00625)
        delta=abs(fi['H_ratio_T']-co['H_ratio_T']);reasons=[]
        if co['label']!=fi['label']:reasons.append('label_disagreement')
        if abs(fi['H_ratio_T']-.5)<=3*delta or abs(fi['H_ratio_T']-1e4/8.2e9)<=3*delta:reasons.append('endpoint_near_threshold')
        ct,ft=co['first_half_crossing'],fi['first_half_crossing'];tdiff=None
        if ct is not None and ft is not None:
            tdiff=abs(ft-ct)
            if min(abs(ft-fi['T']),abs(ft-(fi['T']-10)))<=3*tdiff:reasons.append('crossing_near_horizon_boundary')
        elif (ct is None)!=(ft is None):reasons.append('crossing_presence_disagreement')
        if reasons:refine.add((key[0],key[1]))
        result.append(dict(case_id=key[0],shape=key[1],T=key[2],H_ratio_coarse=co['H_ratio_T'],H_ratio_fine=fi['H_ratio_T'],absolute_step_difference=delta,relative_step_difference=delta/max(fi['H_ratio_T'],1e-300),crossing_time_difference=tdiff,coarse_label=co['label'],fine_label=fi['label'],refinement_reasons=';'.join(reasons)))
    # Check resolution of the sign of each actual policy effect.
    for r in rows:
        if r['h']!=.00625 or r['kind']=='none':continue
        b=next(x for x in rows if x['case_id']==f"S{r['scenario']}_a0_none" and x['shape']==r['shape'] and x['T']==r['T'] and x['h']==r['h'])
        co=next(x for x in rows if x['case_id']==r['case_id'] and x['shape']==r['shape'] and x['T']==r['T'] and x['h']==.0125)
        bc=next(x for x in rows if x['case_id']==b['case_id'] and x['shape']==b['shape'] and x['T']==b['T'] and x['h']==.0125)
        diff=r['H_ratio_T']-b['H_ratio_T'];err=abs(r['H_ratio_T']-co['H_ratio_T'])+abs(b['H_ratio_T']-bc['H_ratio_T'])
        if abs(diff)<=3*err and (err>0 or abs(diff)>0):
            refine.add((r['case_id'],r['shape']));refine.add((b['case_id'],b['shape']))
    return result,refine

def main():
    started=now();tic=time.perf_counter()
    if ROOT.exists(): raise FileExistsError('Choose a new output directory')
    ROOT.mkdir(parents=True)
    reg=json.loads((SOURCE_ROOT/'PREREGISTRATION.json').read_text())
    for name,digest in json.loads((SOURCE_ROOT/'PREREGISTRATION_HASHES.json').read_text()).items():assert sha(SOURCE_ROOT/name)==digest,'preregistration changed'
    assert json.loads((SOURCE_ROOT/'STEP1_DECISION.json').read_text())['D_errors_found']==[]
    putjson(ROOT/'ENVIRONMENT.json',dict(started_at=started,python=sys.version,executable=sys.executable,numpy=np.__version__,platform=platform.platform(),worker_processes=4,baseline_source='model_copy/v4model.py',alternative_source='model_copy/v4model_response.py',preregistration_sha=sha(SOURCE_ROOT/'PREREGISTRATION.json'),entry_source_sha=sha(__file__)))
    print('AUXILIARY_START',started,flush=True)
    tests=auxiliary_tests(reg);putjson(ROOT/'AUXILIARY_TESTS.json',tests)
    print('AUXILIARY_PASS',len(tests),now(),flush=True)
    groups=[]
    for sc in [1,2]:
        groups.append([d for d in reg['design'] if d['scenario']==sc and d['kind']=='none'])
        groups.extend([[d] for d in reg['design'] if d['scenario']==sc and d['kind']!='none'])
    jobs=[(reg,ds,s,h,'main') for ds in groups for s in reg['shapes'] for h in reg['steps']]
    putjson(ROOT/'INPUTS.json',dict(preregistration=reg,actual_parameters=params(reg),source_hashes={p.name:sha(p) for p in (SOURCE_ROOT/'model_copy').glob('*.py')},main_function_calls=len(jobs),main_lanes=64))
    rows=[];logs=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        pending=[pool.submit(execute_job,j) for j in jobs]
        for i,f in enumerate(concurrent.futures.as_completed(pending),1):
            rr,ll=f.result();rows+=rr;logs.append(ll)
            print('JOB',i,'/',len(jobs),ll['job'],round(ll['seconds'],3),now(),flush=True)
    putcsv(ROOT/'RESULTS_MAIN.csv',sorted(rows,key=lambda r:(r['case_id'],r['shape'],r['h'],r['T'])))
    conv,ref=convergence(rows);putcsv(ROOT/'CONVERGENCE_MAIN.csv',conv)
    putjson(ROOT/'REFINEMENT_DECISION.json',dict(rule=reg['refinement_trigger'],affected=sorted(ref),h=.003125,main_steps_complete_at=now()))
    if ref:
        print('LOCAL_REFINEMENT',len(ref),flush=True)
        jobs=[(reg,[next(d for d in reg['design'] if d['id']==cid)],shape,.003125,'refinement') for cid,shape in sorted(ref)]
        extra=[]
        with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
            for f in concurrent.futures.as_completed([pool.submit(execute_job,j) for j in jobs]):
                rr,ll=f.result();extra+=rr;logs.append(ll);print('REFINE_DONE',ll['job'],now(),flush=True)
        putcsv(ROOT/'RESULTS_REFINED.csv',extra);rows+=extra
    # Fine grid fixed comparisons; refined grid values are retained separately if needed.
    fine=[r for r in rows if r['h']==.00625]
    compare=[];policies=[];weights=[]
    for l in fine:
        if l['shape']!='linear':continue
        q=next(r for r in fine if r['case_id']==l['case_id'] and r['T']==l['T'] and r['shape']=='quadratic')
        compare.append(dict(case_id=l['case_id'],scenario=l['scenario'],kind=l['kind'],tau=l['tau'],a=l['a'],T=l['T'],linear_ratio=l['H_ratio_T'],quadratic_ratio=q['H_ratio_T'],ratio_difference=q['H_ratio_T']-l['H_ratio_T'],people_difference=q['H_T']-l['H_T'],linear_first_half_crossing=l['first_half_crossing'],quadratic_first_half_crossing=q['first_half_crossing'],linear_label=l['label'],quadratic_label=q['label'],label_changed=l['label']!=q['label']))
    for r in fine:
        if r['kind']=='none':continue
        b=next(x for x in fine if x['scenario']==r['scenario'] and x['a']==0 and x['kind']=='none' and x['shape']==r['shape'] and x['T']==r['T'])
        policies.append(dict(case_id=r['case_id'],scenario=r['scenario'],kind=r['kind'],tau=r['tau'],shape=r['shape'],T=r['T'],baseline_ratio=b['H_ratio_T'],policy_ratio=r['H_ratio_T'],gain_ratio=r['H_ratio_T']-b['H_ratio_T'],baseline_label=b['label'],policy_label=r['label']))
        if r['kind']=='shutdown_success':
            prob=reg['p0']*(1-r['I_at_event'])
            weights.append(dict(case_id=r['case_id'],scenario=r['scenario'],tau=r['tau'],shape=r['shape'],T=r['T'],p0=reg['p0'],I_tau_minus=r['I_at_event'],assumed_success_weight=prob,success_ratio=r['H_ratio_T'],failure_ratio=b['H_ratio_T'],success_label=r['label'],failure_label=b['label'],weighted_population_ratio=prob*r['H_ratio_T']+(1-prob)*b['H_ratio_T'],**{'weight_'+lab:prob*(r['label']==lab)+(1-prob)*(b['label']==lab) for lab in ['normal','marginal','quasi_extinction']}))
    putcsv(ROOT/'RESPONSE_COMPARISON.csv',compare);putcsv(ROOT/'POLICY_EFFECTS.csv',policies);putcsv(ROOT/'SHUTDOWN_CONDITIONAL_WEIGHTS.csv',weights)
    before=json.loads((REPO/'config/RELEASE_SOURCES.json').read_text())
    after={name:sha(REPO/name) for name in before}
    putjson(ROOT/'FROZEN_HASH_VERIFICATION.json',dict(verified_at=now(),tracked_files=len(before),files_unchanged=before==after,missing=sorted(set(before)-set(after)),added=sorted(set(after)-set(before)),changed=[k for k in set(before)&set(after) if before[k]!=after[k]]))
    assert before==after,'frozen project changed'
    checks=dict(main_lanes=64,main_horizon_records=len([r for r in rows if r['h'] in reg['steps']]),refined_lanes=len(ref),auxiliary_tests=len(tests),max_population_identity_error=max(r['population_identity_error'] for r in rows),max_energy_balance_residual=max(r['energy_balance_residual_TWh_per_yr'] for r in rows),max_land_balance_residual=max(r['land_balance_residual_km2'] for r in rows),min_protected_energy_margin=min(r['protected_energy_floor_min'] for r in rows),min_protected_land_margin=min(r['protected_land_floor_min'] for r in rows),frozen_unchanged=before==after)
    assert checks['main_horizon_records']==128
    assert checks['max_population_identity_error']<1e-9
    assert checks['min_protected_energy_margin']>=-1e-8 and checks['min_protected_land_margin']>=-1e-6
    putjson(ROOT/'RUN_SUMMARY.json',dict(started_at=started,finished_at=now(),wall_seconds=time.perf_counter()-tic,checks=checks,jobs=logs,status='COMPLETED',scope='Registered local comparison only; not full production rerun'))
    print('COMPLETED',json.dumps(checks),now(),flush=True)

if __name__=='__main__':main()
