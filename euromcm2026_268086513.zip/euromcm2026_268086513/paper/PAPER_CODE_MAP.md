# Final paper v8: compact code map

Numerical model V4; paper title: *What Remains for Us? Resource Allocation and Human Fate under RSI*. Final figure numbers were checked in the compiled v8 paper, not inferred from asset names. This map does not bundle the full paper source.

| Chapter | Type and implementation | Evidence / selection | Figures |
|---|---|---|---|
| 1 Introduction | Research questions and schematic | `figures/source/workflow.tex`; final-figure plotting script | 1 |
| 2 Assumptions | Reference values, derived intensities and scenario assumptions | `config/reference_parameters.json`; executed `src/v4model.py:reference_params`; `docs/SOURCES_STATUS_CN.md` | None |
| 3 Common core, history and physical RSI | `src/v4model.py:grid_allocation,simulate`; `src/joint_routing.py`; historical `shares,run,alone_equilibrium` | `results/current/history/`; `reference/history_saved/`; `python run.py history --output runs/history`. Equations and assumptions: `docs/MODEL_CN.md`. Historical density target not reproduced. | 2, 3 |
| 4 Outcome mechanisms | Analytic saturated-system relations plus actual simulated pathways | `data/representative_trajectories.csv`, S1/S2/S3, tau_H=10, tau_phys=3, a=0, T100; `stage4/results_T100.json` and T200, all fixed-grid rows including stress. `paper-checks` checks selected dynamics. | 4, 5 |
| 5 Fate and alignment | Classification: `src/outcomes_delivered.py`. Scans: `experiments/production.py:stage5,stage7`; local refinement and extinction endpoint code retained | Atlas: `stage5/alignment_curves.csv`, tau_phys≈3, S1/S2, both horizons, all a and tau_H (1,968 cells). Boundaries: `thresholds_refined.csv`, stress=False, largest bracket by scenario/T. Shares: `stage7/conditional_shares_audited.csv`, T200, S1/S2, P1/P2/P3, n=500. Recount with `verify`; full dynamics with `reproduce`. | 6, 7 |
| 6 Intervention | `simulate` policy/cap/shutdown/retirement; `production.stage6` | `stage6/branches.csv` and `shutdown_weights.csv`: T100, tau_H≈10,tau_phys≈3,a=0,S1/S2, all tested caps/times. Weight panel uses S1,p0=.5/.9/1. `sampled_deadlines.json` contains sampled times, not universal deadlines. S2 cap example at T200,a=.5,tau_phys≈sqrt(90),cap41.5,tau0 is retained. | 8 |
| 7 Structural/numerical checks | Response supplement, K-scope comparison, growing-grid scenario, 31 scientific tests and 22 backend cases | Figure 9: supplement `results/RESPONSE_COMPARISON.csv`, kind=none, eight pairs. K: `results/current/K_SCOPE_COMPARISON.csv`; selected check via `paper-checks`. Growth: matched stage4/stage22. `VALIDATION.json` distinguishes current checks from prior records and NOT RUN scopes. | 9 |
| 8 Conclusions | Conditional synthesis, no new calculation | Trace numbers to rows above; analytic claims retain their supply/saturation/response assumptions | Prior figures |

All nine figures: `python run.py paper-figures --output runs/paper_figures`. Figure reference/command table: `FIGURE_MAP.csv`. Plotting reads saved results; it is not full experimental reproduction. Output data and source hashes are recorded in each generated manifest.

Main alignment boundaries apply to the linear response and sampled design. They are not universal real-world thresholds. Wilson intervals describe conditional sampling precision; quantities derived from assumed probabilities are not empirically calibrated probabilities. Reduced analytic predictions are labelled separately from saved simulation observations.
