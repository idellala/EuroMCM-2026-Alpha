"""Public entry point. All commands use explicit registered V4 configuration."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'experiments'))
from common import CFG, SCEN, metrics, reference_params, run

PUBLIC_LABELS = {
    'normal': 'criterion_not_met',
    'marginal': 'sustained_marginalisation',
    'quasi_extinction': 'quasi_extinction',
}

def hash_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def positive(value):
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError('Expected a positive finite number')
    return number

def fresh_output(path):
    path = Path(path).resolve()
    if path.exists():
        raise FileExistsError('Existing output is protected; choose a new directory: ' + str(path))
    path.mkdir(parents=True)
    return path

def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')

def snapshot(args, out):
    p = reference_params()
    p.update(mu=math.log(2) / args.tau_h,
             r_phys=p['delta_A'] + math.log(2) / args.tau_phys,
             g_E=args.grid_growth)
    if not 0 <= args.alignment <= 1 or not math.isfinite(args.alignment):
        raise ValueError('Alignment must be in [0, 1]')
    if not math.isfinite(args.grid_growth) or args.grid_growth < 0:
        raise ValueError('Grid growth must be finite and nonnegative')
    if args.horizon / args.step > 2_000_000:
        raise ValueError('More than two million recorded steps; use the batch workflow')
    policy = None
    if args.policy != 'none':
        if args.tau is None or not 0 <= args.tau <= args.horizon:
            raise ValueError('Policy time must lie in the simulation horizon')
        if args.policy == 'cap':
            if args.cap is None or args.cap < 0 or not math.isfinite(args.cap):
                raise ValueError('Cap must be finite and nonnegative')
            policy = dict(kind='cap', tau=args.tau, cap=args.cap)
        else:
            policy = dict(kind='shutdown', tau=args.tau, success=not args.shutdown_fails)
    tr = run(p, [args.alignment], args.scenario, args.horizon, args.step, policy)
    summary = metrics(tr, p)[0]
    from outcomes_delivered import classify_arrays
    import numpy as np
    classification = classify_arrays(tr.t, tr.rec['H'][:, 0], np.ones(len(tr.t)),
                                     dict(H0=p['H0'], H_ext=p['H_ext'], eta=p['eta'], W=p['W'], q_bar=.5))
    episodes = classification['population_episodes']
    summary.update(raw_label=summary.pop('label'),
                   terminal_population_below_half=bool(tr.rec['H'][-1, 0] < .5 * p['H0']),
                   first_population_half_crossing=episodes[0]['start'] if episodes else None)
    summary['public_label'] = PUBLIC_LABELS[summary['raw_label']]
    summary['interpretation'] = 'criterion_not_met does not mean small population loss or future safety'
    write_json(out / 'summary.json', summary)
    with (out / 'trajectory.csv').open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['year', 'population_ratio', *tr.rec.keys()])
        writer.writerows([float(t), float(tr.rec['H'][i, 0] / p['H0']),
                          *[float(value[i, 0]) for value in tr.rec.values()]] for i, t in enumerate(tr.t))
    return dict(parameters=p, scenario=args.scenario, structural_scenario=SCEN[args.scenario],
                alignment=args.alignment, horizon=args.horizon, step=args.step,
                main_configuration=CFG, policy=policy)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sim = sub.add_parser('simulate', help='Run one explicit main-configuration scenario')
    sim.add_argument('--scenario', type=int, choices=SCEN, default=1)
    sim.add_argument('--alignment', type=float, default=0.)
    sim.add_argument('--tau-h', type=positive, default=50.)
    sim.add_argument('--tau-phys', type=positive, default=10.)
    sim.add_argument('--horizon', type=positive, default=100.)
    sim.add_argument('--step', type=positive, default=.0125)
    sim.add_argument('--grid-growth', type=float, default=0.)
    sim.add_argument('--policy', choices=['none', 'cap', 'shutdown'], default='none')
    sim.add_argument('--tau', type=float)
    sim.add_argument('--cap', type=float)
    sim.add_argument('--shutdown-fails', action='store_true')
    sim.add_argument('--output', required=True)
    for name, help_text in [('verify', 'Check the delivered results and calculate paper tables'),
                             ('test', 'Run scientific and public-interface tests'),
                             ('backend', 'Validate 22 C++/Python reference cases'),
                             ('history', 'Reproduce the registered historical comparison'),
                             ('paper-checks', 'Compare selected paper trajectories and saved figures'),
                             ('paper-figures', 'Replot the nine final-paper figures from delivered evidence'),
                             ('reproduce', 'Run the full numerical workflow; potentially expensive')]:
        p = sub.add_parser(name, help=help_text)
        p.add_argument('--output', required=True)
        if name in ('verify', 'paper-figures'):
            p.add_argument('--results', default=str(ROOT / 'results/current'))
    args = parser.parse_args()
    if args.command == 'paper-figures':
        subprocess.run([sys.executable, '-B', str(ROOT/'scripts/build_paper_figures.py'),
                        '--output', str(Path(args.output).resolve()), '--results', str(Path(args.results).resolve())], check=True)
        return
    out = fresh_output(args.output)
    receipt = dict(command=args.command, status='RUNNING',
                   python=sys.version, main_configuration=CFG,
                   source_hashes={str(p.relative_to(ROOT)): hash_file(p) for d in ('src','experiments','scripts','tests')
                                  for p in (ROOT/d).rglob('*') if p.is_file() and p.suffix in ('.py','.cpp')},
                   entry_sha256=hash_file(__file__))
    write_json(out/'RUN.json', receipt)
    try:
        env = dict(os.environ, V4_TEST_OUTPUT=str(out), V4_OUTPUT_ROOT=str(out))
        if args.command == 'simulate':
            receipt['inputs'] = snapshot(args, out)
        elif args.command == 'verify':
            from release_checks import verify_results
            verify_results(Path(args.results).resolve(), out)
        elif args.command == 'test':
            for file in ('run_tests.py', 'test_release.py'):
                subprocess.run([sys.executable, '-B', str(ROOT/'tests'/file)], env=env, check=True)
        elif args.command == 'backend':
            subprocess.run([sys.executable, '-B', str(ROOT/'tests/validate_backend.py')], env=env, check=True)
        elif args.command == 'paper-checks':
            subprocess.run([sys.executable, '-B', str(ROOT/'experiments/paper_checks.py'), '--output', str(out/'selected')], env=env, check=True)
        elif args.command == 'history':
            subprocess.run([sys.executable, '-B', str(ROOT/'experiments/history_rerun.py')], env=env, check=True)
        elif args.command == 'reproduce':
            from reproduce_release import reproduce
            reproduce(out)
        receipt['status'] = 'PASS'
    except Exception as error:
        receipt.update(status='FAIL', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        write_json(out/'RUN.json', receipt)
    print(json.dumps(dict(status=receipt['status'], command=args.command, output=str(out))))

if __name__ == '__main__':
    main()
