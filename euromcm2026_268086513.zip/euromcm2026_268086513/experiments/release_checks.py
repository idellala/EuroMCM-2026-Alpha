"""Independent saved-result verification and unambiguous public reporting."""
import collections
import csv
import hashlib
import json
import math
from pathlib import Path

PUBLIC = {'normal': 'criterion_not_met', 'marginal': 'sustained_marginalisation',
          'quasi_extinction': 'quasi_extinction'}

def read(path):
    with Path(path).open() as f:
        return list(csv.DictReader(f))

def write_csv(path, rows):
    if not rows:
        raise ValueError('Cannot silently write an empty evidence table')
    with Path(path).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)

def verify_results(base, out):
    base, out = Path(base), Path(out)
    checks = []
    def check(name, condition, detail=None):
        checks.append(dict(name=name, status='PASS' if condition else 'FAIL', detail=detail))
    samples = read(base/'stage7/sample_results_audited.csv')
    shares = read(base/'stage7/conditional_shares_audited.csv')
    bounds = read(base/'stage5/thresholds_refined.csv')
    branches = read(base/'stage6/branches.csv')
    weights = read(base/'stage6/shutdown_weights.csv')
    key = lambda r: tuple(r[k] for k in ('prior','scenario','a','T'))
    groups = collections.defaultdict(list)
    for r in samples: groups[key(r)].append(r)
    check('registered_counts', (len(samples),len(shares),len(bounds),len(branches),len(weights)) == (36000,288,864,22680,13608))
    check('sample_units_and_sizes', len(groups)==72 and all(len(v)==500 for v in groups.values()))
    failures=[]
    for r in shares:
        group=groups[key(r)]; n=len(group); k=sum(s['category']==r['category'] for s in group)
        p=k/n; z=1.959963984540054; den=1+z*z/n
        center=(p+z*z/(2*n))/den; half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
        if int(r['count'])!=k or int(r['n'])!=n or abs(float(r['conditional_share'])-p)>1e-14 or abs(float(r['wilson95_low'])-(center-half))>1e-14 or abs(float(r['wilson95_high'])-(center+half))>1e-14:
            failures.append(key(r))
    check('independent_counts_and_wilson', not failures, dict(error_rows=len(failures)))
    check('categories_partition',all(sum(int(r['count']) for r in shares if key(r)==k)==500 for k in groups))
    check('no_unresolved_sample_rows',all(r['unresolved'] not in ('True','true') for r in samples))
    check('protected_resource_floor',all(float(r['min_q'])>=float(r['a'])-1e-9 for r in samples+branches))
    check('branch_weights_sum',all(abs(sum(float(r['weight_'+lab]) for lab in PUBLIC)-1)<1e-12 for r in weights))
    check('classification_never_weighted_before_branching',all(r['success_label'] in PUBLIC and r['failure_label'] in PUBLIC for r in weights))
    check('criterion_brackets_width',all(0<=float(r['bracket_lower'])<=float(r['bracket_upper'])<=1 and float(r['bracket_upper'])-float(r['bracket_lower'])<=.001+1e-12 for r in bounds))
    check('criterion_brackets_resolved',all(r['refinement_status']!='unresolved_numeric_boundary' and r['grid_labels_stable']=='True' for r in bounds))
    endpoints=read(base/'stage5/EXTINCTION_BOUNDARY_ENDPOINT_CHECKS.csv')
    positive_extinction_brackets=sum(float(r.get('a_ext_bracket_upper') or 0)>0 for r in bounds)
    check('saved_finer_extinction_endpoints',len(endpoints)==positive_extinction_brackets and all(r['valid']=='True' for r in endpoints), 'Saved dynamic evidence, not newly integrated here')
    # Derived presentation layer never alters original labels or thresholds.
    public=[]
    for r in samples:
        public.append(dict(prior=r['prior'],sample=r['sample'],scenario=r['scenario'],a=r['a'],T=r['T'],
                           raw_label=r['label'],public_label=PUBLIC[r['label']],
                           H_ratio_T=r['H_ratio_T'],terminal_population_below_half=float(r['H_ratio_T'])<.5,
                           first_half_crossing=r.get('first_cross_raw',''),
                           source='stage7/sample_results_audited.csv'))
    write_csv(out/'PUBLIC_SAMPLE_OUTCOMES.csv',public)
    semantic=[]
    for k, rr in groups.items():
        for raw in PUBLIC:
            selected=[r for r in rr if r['label']==raw]
            semantic.append(dict(zip(('prior','scenario','a','T'),k),raw_label=raw,public_label=PUBLIC[raw],
                                 count=len(selected),count_terminal_below_half=sum(float(r['H_ratio_T'])<.5 for r in selected),
                                 min_terminal_ratio=min((float(r['H_ratio_T']) for r in selected),default='')))
    write_csv(out/'CLASSIFICATION_CAVEAT_TABLE.csv',semantic)
    # Record numerical step differences, not claims of rigorous error bounds.
    numerical=[]
    for stage in ('stage4','stage22'):
        for T in (100,200):
            d=json.loads((base/stage/f'results_T{T}.json').read_text())['rows']
            allrows=[dict(r,scenario=int(sc)) for sc,rr in d.items() for r in rr]
            check(f'{stage}_{T}_design',len(allrows)==1296 and all(r.get('label_stable',True) for r in allrows))
            for stress in (False,True):
                worst=max((r for r in allrows if r['stress']==stress),key=lambda r:r['err_H_ratio'])
                numerical.append(dict(stage=stage,T=T,stress=stress,scenario=worst['scenario'],tau_H=worst['tau_H'],tau_phys=worst['tau_phys'],a=worst['a'],step_difference=worst['err_H_ratio'],note='h versus h/2; not a rigorous error bound'))
    write_csv(out/'NUMERICAL_PRECISION.csv',numerical)
    report=dict(status='PASS' if all(r['status']=='PASS' for r in checks) else 'FAIL',checks=checks,
                normal_label_terminal_below_half=sum(r['raw_label']=='normal' and r['terminal_population_below_half'] for r in public),
                scope='Full table recomputation; no claim of full dynamic rerun',
                input_sha256={str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in base.rglob('*') if p.is_file()})
    (out/'RESULT_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
    if report['status']!='PASS':raise RuntimeError('Result verification failed; see RESULT_VERIFICATION.json')
    return report
