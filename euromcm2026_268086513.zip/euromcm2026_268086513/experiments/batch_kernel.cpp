// Streaming transcription of frozen V4 updates. No fast-math, no new equations.
#include <cmath>
#include <algorithm>
#include <limits>
using std::min; using std::max;
static constexpr double EVENT_ATOL=1e-12;
static double clip0(double x){return max(0.,x);}
static double snap(double x,double b){double u=std::nextafter(b,INFINITY)-b;return std::abs(x-b)<=16*u?b:x;}
// p: H0,E0,L0,en,ell,eps,F,delta,rA0,Ghw,g,Cmax,kappa,chi,Aref,ld,lg,Lother,Hext,eta,W,f
// jobs: tau_H,tau_phys,a,T,h,scenario,policy_kind,tau,cap,phi,gE
// outputs two 20-column snapshots (100 if present, and T); T=100 duplicates.
extern "C" void batch(int n,const double* p,const double* jobs,double* output){
 for(int j=0;j<n;j++){
  const double* z=jobs+11*j; double th=z[0],tp=z[1],a=z[2],T=z[3],h=z[4];
  int sc=(int)z[5],kind=(int)z[6];double tau=z[7],cap=z[8],phi=z[9],ge=z[10];
  if(std::abs(tau-std::round(tau/h)*h)<=EVENT_ATOL)tau=std::round(tau/h)*h;
  bool self=(sc==2||sc==4),e2=(sc==3||sc==4),shut=(kind==2&&tau==0.);
  double H=p[0],Ag=p[21]*415.,As=0.,C=1.,I=0.;
  double mu=std::log(2.)/th,rphys=p[7]+std::log(2.)/tp;
  double minq=1.,S=0.,mx=0.,mi=0.,cross=-1.,ext=-1.,res=0.;
  int steps=(int)std::round(T/h);
  int k=0; double t=0.;
  while(true){
   double SH=min(1.,H/(p[13]*p[0]));
   double E=p[1]*std::exp(ge*t)*(I+(1-I)*SH),DE=p[3]*H,DL=p[4]*H;
   double PE=a*min(E,DE),PL=a*min(p[2],DL),U=E-PE;
   double Kpol=(kind==1&&t>=tau-1e-12)?cap:INFINITY;
   double ar;
   if(shut)ar=0.;
   else if(std::isinf(phi))ar=min(min(Ag,U),Kpol);
   else {double hh=max(DE-PE,0.),wc=phi*Ag;double share=(wc+hh)>0?U*wc/(wc+hh):0.;ar=min(min(Ag,max(U-hh,share)),Kpol);}
   double EH=E-ar;
   double energyTol=32*(std::nextafter(E,INFINITY)-E);
   if(PE-EH>energyTol)EH=std::numeric_limits<double>::quiet_NaN();
   else if(EH<PE)EH=PE;
   double ls=p[15]+p[16],Lam=p[15]*Ag+ls*As,LamL=max(0.,Lam-p[17]),LH=p[2]-LamL;
   double landTol=32*(std::nextafter(p[2],INFINITY)-p[2]);
   if(std::abs((p[2]-PL)-LamL)<=landTol){LH=PL;LamL=p[2]-LH;}
   double Arun=shut?0.:ar+As,qE=e2?(EH+p[6])/(DE/p[5]):EH/DE,qL=LH/DL,q=min(1.,min(qE,qL));
   minq=min(minq,q);mx=max(mx,Arun/p[1]);mi=max(mi,(Ag+As)/p[1]);
   res=max(res,max(std::abs(EH+ar-E),std::abs(LH+LamL-p[2])/1000.));
   if(k==steps||std::abs(t-100.)<1e-10){
    int slot=k==steps?1:0;double *o=output+j*40+slot*20;
    bool marginal=cross>=0. && t-cross+1e-10>=p[20];
    o[0]=H/p[0];o[1]=H;o[2]=Ag;o[3]=As;o[4]=C;o[5]=I;o[6]=minq;o[7]=q;o[8]=S;o[9]=mx;o[10]=mi;
    o[11]=marginal?cross:-1.;o[12]=ext;o[13]=ext>=0?2:(marginal?1:0);o[14]=res;o[15]=std::abs(std::log(H/p[0])+mu*S);
    o[16]=cross;o[17]=ar/E;o[18]=E/p[1];o[19]=Arun/p[1];
    if(k==steps && T==100.)std::copy(o,o+20,output+j*40);
   }
   if(k==steps)break;
   double next=(k+1)*h;
   if(kind && tau>t+EVENT_ATOL && tau<next-EVENT_ATOL)next=tau;
   double dt=next-t;
   double Hn=H*std::exp(-mu*(1-q)*dt);
   double w=min(1.,Arun/p[14]);
   double Cn=p[11]/(1+(p[11]/C-1)*std::exp(-p[10]*w*dt));
   double In=1-(1-I)*std::exp(-p[12]*w*C*dt);
   double ghcap=(1-I)*SH*p[9],gacap=I*rphys*Arun,des=p[8]*C*Arun,tot=ghcap+gacap;
   double s=tot>des?(tot>0?des/tot:0.):1.,gh=shut?0.:s*ghcap,ga=shut?0.:s*gacap;
   double fac=-std::expm1(-p[7]*dt)/p[7],decay=std::exp(-p[7]*dt);
   double dg=(self?gh:gh+ga)*fac,ds=self?ga*fac:0.;
   double retiredLam=Lam*decay,retiredLamL=max(0.,retiredLam-p[17]);
   double B=clip0(p[17]-min(retiredLam,p[17]))+clip0(p[2]-PL-retiredLamL),gr=0.,sr=0.,fg=0.;
   if(self){
    double need=p[15]*dg,scale=need>B*(1+1e-12)?(need>0?B/need:0.):1.;
    gr=min(scale*dg,clip0(min(U,Kpol)-Ag*decay));
    double left=clip0(B-p[15]*gr),K=clip0(min(U,Kpol)-Ag*decay-gr);
    if(p[16]==0.){sr=min(ds,left/p[15]);fg=0.;}
    else {double xmin=max(0.,(ls*ds-left)/p[16]);
     if(xmin<=min(ds,K)){fg=xmin;sr=ds-fg;}
     else {fg=min(min(K,ds),left/p[15]);sr=max(0.,(left-p[15]*fg)/ls);}}
   }else{
    double need=p[15]*dg,scale=need>B*(1+1e-12)?(need>0?B/need:0.):1.;
    gr=min(scale*dg,clip0(min(U,Kpol)-Ag*decay));
   }
   if(shut)fg=0.;
   Ag=Ag*decay+gr+fg;As=As*decay+sr;S+=(1-q)*dt;
   double eta=p[19]*p[0];
   if(cross<0 && snap(Hn,eta)<eta){
    cross=H>=eta?t+dt*std::log(eta/H)/std::log(Hn/H):t;}
   if(ext<0 && snap(Hn,p[18])<p[18]){
    ext=H>=p[18]?t+dt*std::log(p[18]/H)/std::log(Hn/H):t;}
   H=Hn;C=Cn;I=In;
   if(kind==2&&std::abs(next-tau)<=EVENT_ATOL)shut=true;
   if(std::abs(next-(k+1)*h)<=EVENT_ATOL)++k;
   t=next;
  }
 }
}
