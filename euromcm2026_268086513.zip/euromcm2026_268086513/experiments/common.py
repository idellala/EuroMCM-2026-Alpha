"""Experiment helpers; the repaired scientific model is imported explicitly."""
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from v4model import reference_params, simulate
from outcomes_delivered import classify_arrays

CFG = dict(routing='joint', phi_E=1., k_scope='all')
SCEN = {1: ('E1', 'grid'), 2: ('E1', 'self'), 3: ('E2', 'grid'), 4: ('E2', 'self')}
HGRID = np.exp(np.linspace(np.log(10.), np.log(200.), 9))
PGRID = np.exp(np.linspace(np.log(3.), np.log(30.), 9))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(p, alignment, scenario, T, h, policy=None):
    return simulate(p, alignment, *SCEN[int(scenario)], T=T, h=h, policy=policy, **CFG)


def metrics(tr, p):
    """Valid for the registered r_H=0, adequately supplied no-RSI baseline.

    Classify actual H for extinction and H/H_noRSI for marginalisation. These
    coincide with classifier H/H0 in the registered constant-H0 baseline.
    S is the left-endpoint deficit integral matching the frozen H update.
    """
    if p['r_H'] != 0:
        raise ValueError('This runner requires the registered zero-growth baseline')
    R, t = tr.rec, tr.t
    pars = dict(H0=p['H0'], H_ext=p['H_ext'], eta=p['eta'], W=p['W'], q_bar=.5)
    output = []
    for j in range(R['H'].shape[1]):
        c = classify_arrays(t, R['H'][:, j], np.ones(len(t)), pars)
        entry = c['first_marginal_entry']
        short = float(np.sum((1-R['q'][:-1,j])*np.diff(t)))
        output.append(dict(H_ratio_T=float(R['H'][-1,j]/p['H0']),
                           deficit_people=float(p['H0']-R['H'][-1,j]),
                           H_T=float(R['H'][-1,j]), label=c['label'],
                           t_eta=None if entry is None else entry-p['W'],
                           first_marginal_entry=entry,
                           first_quasi_extinction=c['first_quasi_extinction'],
                           min_q=float(np.min(R['q'][:,j])), deficit_years=short,
                           max_m_run=float(np.max(R['A_run'][:,j])/p['E0_ref']),
                           max_m_installed=float(np.max((R['A_g'][:,j]+R['A_s'][:,j]))/p['E0_ref']),
                           population_identity_error=float(abs(math.log(R['H'][-1,j]/p['H0'])+np.asarray(p['mu']).flat[min(j,np.asarray(p['mu']).size-1)]*short)),
                           conservation_residual=tr.meta['max_conservation_residual']))
    return output


def write_json(path, data):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists(): raise FileExistsError('Append-only run: choose a new run directory')
    def encode(value):
        if isinstance(value,np.generic):return value.item()
        if isinstance(value,np.ndarray):return value.tolist()
        raise TypeError('Unsupported JSON type: '+type(value).__name__)
    p.write_text(json.dumps(data,indent=2,allow_nan=False,default=encode))


def write_csv(path, rows):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists(): raise FileExistsError(p)
    if not rows: return
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
