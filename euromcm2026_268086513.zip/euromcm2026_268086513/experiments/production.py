import os
"""Registered production. Uses validated frozen-model transcription, writes append-only evidence."""
import argparse,collections,csv,json,math,sys,time
from pathlib import Path
import numpy as np
from common import ROOT,HGRID,PGRID,reference_params,write_json,write_csv,sha
from fast_batch import jobs_run,decode

START=time.time();P=reference_params();BASE=Path(os.environ.get('V4_OUTPUT_ROOT',str(ROOT/'runs/full_reproduction')))

def execute(jobs,label):
    jobs=np.asarray(jobs,float).reshape(-1,11);parts=[]
    for k in range(0,len(jobs),256):
        parts.append(jobs_run(jobs[k:k+256]))
        if k%2048==0 or k+256>=len(jobs):print(label,min(k+256,len(jobs)),'/',len(jobs),'elapsed',round(time.time()-START,1),flush=True)
    return np.concatenate(parts) if parts else np.empty((0,2,20))

def job(th,tp,a,T,h,sc,kind=0,tau=0,cap=1e100):return [float(th),float(tp),float(a),float(T),float(h),float(sc),float(kind),float(tau),float(cap),1.,0.]

def baseline_key(r):return tuple(r[x] for x in ('T','scenario','tau_H','tau_phys','a'))

def stage6():
    dest=BASE/'stage6';metadata=[];jobs=[];bases={}
    for T in (100,200):
        for sc in (1,2,3,4):
            for th in HGRID[[0,4,8]]:
                for tp in PGRID[[0,4,8]]:
                    for a in (0.,.5,.9):
                        key=(T,sc,float(th),float(tp),a);bases[key]=len(bases)
    bj=[job(k[2],k[3],k[4],k[0],.00625,k[1]) for k in bases]
    br=execute(bj,'stage6-baseline-fine');bc=execute([z[:4]+[.0125]+z[5:] for z in bj],'stage6-baseline-coarse')
    for key in bases:
        T,sc,th,tp,a=key
        for kind,cap in [(1,c) for c in (41.5,415.,945.,3125.6)]+[(2,1e100)]:
            for tau in np.linspace(0,T,21):
                metadata.append(dict(T=T,scenario=sc,tau_H=th,tau_phys=tp,a=a,kind='cap' if kind==1 else 'shutdown_success',cap=None if kind==2 else cap,tau=float(tau)))
                jobs.append(job(th,tp,a,T,.00625,sc,kind,tau,cap))
    fine=execute(jobs,'stage6-fine');coarse=execute([z[:4]+[.0125]+z[5:] for z in jobs],'stage6-coarse')
    flags=[i for i,(f,c) in enumerate(zip(fine,coarse)) if abs(f[1,0]-.5)<.05 or f[1,13]!=c[1,13]]
    refined=dict(zip(flags,execute([jobs[i][:4]+[.003125]+jobs[i][5:] for i in flags],'stage6-h4')))
    rows=[];weights=[]
    # Autonomy before each intervention from the original frozen Python simulator;
    # it is independent of the intervention branch and common to every cap/p0.
    from common import run
    Icache={}
    from v4model import simulate
    for T in (100,200):
        for sc in (1,2,3,4):
            keys=[k for k in bases if k[0]==T and k[1]==sc]
            p=reference_params();p.update(mu=np.array([math.log(2)/k[2] for k in keys]),r_phys=np.array([P['delta_A']+math.log(2)/k[3] for k in keys]))
            tr=run(p,[k[4] for k in keys],sc,T,.00625)
            for j,k in enumerate(keys):
                for tau in np.linspace(0,T,21):Icache[(k,float(tau))]=float(tr.rec['I'][int(round(tau/.00625)),j])
            del tr
    for i,(meta,f,c) in enumerate(zip(metadata,fine,coarse)):
        key=baseline_key(meta);bidx=bases[key];b=decode(br[bidx,1]);m=decode(f[1]);er=abs(f[1,0]-c[1,0]);be=abs(br[bidx,1,0]-bc[bidx,1,0]);ref=refined.get(i)
        stable=m['label']==decode(c[1])['label'] and (ref is None or decode(ref[1])['label']==m['label'])
        row=dict(meta,**m,err_H_ratio=float(er),label_stable=stable,h4_label=None if ref is None else decode(ref[1])['label'],baseline_label=b['label'],baseline_H_ratio=b['H_ratio_T'],gain_H_ratio=m['H_ratio_T']-b['H_ratio_T'],gain_numerically_resolved=abs(m['H_ratio_T']-b['H_ratio_T'])>3*(er+be))
        rows.append(row)
        if meta['kind']=='shutdown_success':
            for p0 in (.5,.9,1.):
                prob=p0*(1-Icache[(key,meta['tau'])]);weights.append(dict(meta,p0=p0,p_success=prob,weighted_H_ratio=prob*m['H_ratio_T']+(1-prob)*b['H_ratio_T'],success_label=m['label'],failure_label=b['label'],success_H_ratio=m['H_ratio_T'],failure_H_ratio=b['H_ratio_T'],**{'weight_'+lab:prob*(m['label']==lab)+(1-prob)*(b['label']==lab) for lab in ('normal','marginal','quasi_extinction')}))
    write_csv(dest/'branches.csv',rows);write_csv(dest/'shutdown_weights.csv',weights)
    groups=collections.defaultdict(list)
    for r in rows:groups[tuple(r[k] for k in ('T','scenario','tau_H','tau_phys','a','kind','cap'))].append(r)
    deadlines=[]
    for key,rr in groups.items():
        rr=sorted(rr,key=lambda r:r['tau']);safe=[r['label']=='normal' for r in rr];mono=not any(not safe[i] and safe[i+1] for i in range(len(safe)-1));ts=[r['tau'] for r in rr if r['label']=='normal'];stable=all(r['label_stable'] for r in rr);bn=rr[0]['baseline_label']=='normal'
        deadlines.append(dict(zip(('T','scenario','tau_H','tau_phys','a','kind','cap'),key),safe_time_set=ts,baseline_already_normal=bn,monotone_on_sampled_times=mono,labels_numerically_stable=stable,last_sampled_effective_time=max(ts) if ts and mono and stable and not bn else None))
    write_json(dest/'sampled_deadlines.json',deadlines)
    summ=dict(branch_rows=len(rows),shutdown_weight_rows=len(weights),h4_trajectories=len(flags),unresolved_label_rows=sum(not r['label_stable'] for r in rows),max_population_identity_error=max(r['population_identity_error'] for r in rows),cap_harm_rows=sum(r['kind']=='cap' and r['gain_H_ratio']<0 and r['gain_numerically_resolved'] for r in rows))
    write_json(dest/'summary.json',summ);print('STAGE6',json.dumps(summ),flush=True)

def stage5():
    dest=BASE/'stage5';ths=np.r_[HGRID,[1.,2.,5.]];av=np.linspace(0,1,41);keys=[];jobs=[]
    for sc in (1,2,3,4):
        for th in ths:
            for tp in PGRID:
                for a in av:keys.append((sc,float(th),float(tp),float(a)));jobs.append(job(th,tp,a,200,.00625,sc))
    fine=execute(jobs,'stage5-fine');coarse=execute([z[:4]+[.0125]+z[5:] for z in jobs],'stage5-coarse')
    flags=[i for i,(f,c) in enumerate(zip(fine,coarse)) if np.any(abs(f[:,0]-.5)<.05) or np.any(f[:,13]!=c[:,13])]
    refined=dict(zip(flags,execute([jobs[i][:4]+[.003125]+jobs[i][5:] for i in flags],'stage5-h4')))
    curves=[];groups=collections.defaultdict(list)
    for i,(key,f,c) in enumerate(zip(keys,fine,coarse)):
        sc,th,tp,a=key
        for slot,T in enumerate((100,200)):
            m=decode(f[slot]);ref=refined.get(i);stable=m['label']==decode(c[slot])['label'] and (ref is None or decode(ref[slot])['label']==m['label'])
            r=dict(scenario=sc,tau_H=th,tau_phys=tp,a=a,T=T,stress=th<10-1e-9,**m,err_H_ratio=float(abs(f[slot,0]-c[slot,0])),label_stable=stable)
            curves.append(r);groups[(sc,th,tp,T)].append(r)
    thresholds=[];pending=[];suff_fail=[];mono_viol=[]
    for key,rr in groups.items():
        rr=sorted(rr,key=lambda r:r['a']);a_safe=next((r['a'] for j,r in enumerate(rr) if all(x['label']=='normal' for x in rr[j:])),None)
        a_ext=next((r['a'] for j,r in enumerate(rr) if all(x['label']!='quasi_extinction' for x in rr[j:])),None)
        upper=all(not(rr[i]['label']=='normal' and rr[i+1]['label']!='normal') for i in range(40))
        mono=all(rr[i+1]['H_ratio_T']>=rr[i]['H_ratio_T']-3*(rr[i]['err_H_ratio']+rr[i+1]['err_H_ratio']) for i in range(40))
        sc,th,tp,T=key;suff=max(0.,1-th/(T-P['W']));ceil=float(av[min(40,int(np.searchsorted(av,suff,side='left')))])
        r=dict(scenario=sc,tau_H=th,tau_phys=tp,T=T,stress=th<10-1e-9,a_grid_safe=a_safe,a_grid_avoid_extinction=a_ext,a_suff=suff,a_suff_grid_ceiling=ceil,upward_closed_on_grid=upper,population_monotone_within_error=mono,grid_labels_stable=all(x['label_stable'] for x in rr),bracket_lower=0. if a_safe==0 else (None if a_safe is None else float(av[np.searchsorted(av,a_safe)-1])),bracket_upper=a_safe,refinement_status='not_needed' if a_safe==0 else 'not_refined')
        if a_safe is not None and a_safe>ceil+1e-12:suff_fail.append(key)
        if not mono or not upper:mono_viol.append(key)
        thresholds.append(r)
        if a_safe is not None and a_safe>0 and mono and upper and r['grid_labels_stable']:pending.append(len(thresholds)-1)
    # Local bracket estimates; sampled monotonicity is not a proof on all real a.
    for iteration in range(5):
        jj=[]
        for i in pending:
            r=thresholds[i];mid=(r['bracket_lower']+r['bracket_upper'])/2;jj.append(job(r['tau_H'],r['tau_phys'],mid,r['T'],.00625,r['scenario']))
        ff=execute(jj,'stage5-bisection-fine-'+str(iteration));cc=execute([z[:4]+[.0125]+z[5:] for z in jj],'stage5-bisection-coarse-'+str(iteration));new=[]
        for n,i in enumerate(pending):
            r=thresholds[i];slot=1;f=decode(ff[n,slot]);c=decode(cc[n,slot]);mid=jj[n][2]
            if f['label']!=c['label']:
                r['refinement_status']='unresolved_numeric_boundary';continue
            if f['label']=='normal':r['bracket_upper']=mid
            else:r['bracket_lower']=mid
            r['refinement_status']='estimated_bracket_assuming_no_unsampled_reversal'
            if r['bracket_upper']-r['bracket_lower']>.001:new.append(i)
        pending=new
        if not pending:break
    write_csv(dest/'alignment_curves.csv',curves);write_csv(dest/'thresholds.csv',thresholds)
    summary=dict(curve_rows=len(curves),threshold_rows=len(thresholds),h4_trajectories=len(flags),sufficient_condition_failures=suff_fail,monotonicity_violations=mono_viol,unresolved_curve_labels=sum(not r['label_stable'] for r in curves),refinement_status=dict(collections.Counter(r['refinement_status'] for r in thresholds)),scope='Grid-based boundaries and locally estimated brackets, not universal continuous minima')
    write_json(dest/'summary.json',summary)
    if suff_fail:raise RuntimeError('Sufficient-condition grid test failed')
    print('STAGE5',json.dumps(summary),flush=True)

def wilson(k,n):
    z=1.959963984540054;p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;return center-half,center+half

def stage7():
    dest=BASE/'stage7';keys=[];jobs=[];samples=[]
    for pi in (1,2,3):
        seed=20261017+pi;rng=np.random.default_rng(seed)
        if pi in (1,2):th=np.exp(rng.uniform(math.log(10 if pi==1 else 1),math.log(200),500));tp=np.exp(rng.uniform(math.log(3),math.log(30),500))
        else:th=rng.uniform(10,200,500);tp=rng.uniform(3,30,500)
        for i,(hh,pp) in enumerate(zip(th,tp)):samples.append(dict(prior='P'+str(pi),seed=seed,sample=i,tau_H=float(hh),tau_phys=float(pp)))
        for sc in (1,2,3,4):
            for a in (0.,.5,.9):
                for i,(hh,pp) in enumerate(zip(th,tp)):keys.append((pi,seed,sc,a,i,float(hh),float(pp)));jobs.append(job(hh,pp,a,200,.0125,sc))
    initial=execute(jobs,'stage7-main');flag=[]
    for i,o in enumerate(initial):
        if any(abs(o[s,0]-.5)<.05 or abs(math.log(max(o[s,1],1e-300)/P['H_ext']))<.1 or (o[s,16]>=0 and abs(o[s,16]-([100,200][s]-P['W']))<1.) for s in (0,1)):flag.append(i)
    fine=dict(zip(flag,execute([jobs[i][:4]+[.00625]+jobs[i][5:] for i in flag],'stage7-h2')))
    changed=[i for i in flag if np.any(initial[i,:,13]!=fine[i][:,13])]
    finer=dict(zip(changed,execute([jobs[i][:4]+[.003125]+jobs[i][5:] for i in changed],'stage7-h4')))
    rows=[];groups=collections.defaultdict(list)
    for i,(key,o) in enumerate(zip(keys,initial)):
        pi,seed,sc,a,sid,th,tp=key
        selected=finer.get(i,fine.get(i,o))
        for slot,T in enumerate((100,200)):
            m=decode(selected[slot]);changed0=m['label']!=decode(o[slot])['label'];unresolved=i in finer and decode(finer[i][slot])['label']!=decode(fine[i][slot])['label']
            category=m['label'] if m['label']!='normal' else ('normal_loss_ge_10pct' if m['H_ratio_T']<.9 else 'normal_loss_lt_10pct')
            r=dict(prior='P'+str(pi),seed=seed,sample=sid,scenario=sc,a=a,T=T,tau_H=th,tau_phys=tp,category=category,refined=i in fine,label_changed_from_main=changed0,unresolved=unresolved,**m);rows.append(r);groups[(pi,sc,a,T)].append(r)
    stats=[]
    for key,rr in groups.items():
        pi,sc,a,T=key
        for cat in ('quasi_extinction','marginal','normal_loss_ge_10pct','normal_loss_lt_10pct'):
            count=sum(r['category']==cat for r in rr);n=len(rr);lo,hi=wilson(count,n)
            stats.append(dict(prior='P'+str(pi),scenario=sc,a=a,T=T,category=cat,n=n,count=count,conditional_share=count/n,wilson95_low=lo,wilson95_high=hi,MCSE=math.sqrt((count/n)*(1-count/n)/n),H_q05=float(np.quantile([r['H_ratio_T'] for r in rr],.05)),H_q50=float(np.quantile([r['H_ratio_T'] for r in rr],.5)),H_q95=float(np.quantile([r['H_ratio_T'] for r in rr],.95)),unresolved=sum(r['unresolved'] for r in rr)))
    write_csv(dest/'parameter_draws.csv',samples);write_csv(dest/'sample_results.csv',rows);write_csv(dest/'conditional_shares.csv',stats)
    summary=dict(parameter_draws=len(samples),T200_trajectories=len(jobs),horizon_rows=len(rows),units=len(groups),N_per_unit=500,h2_refined=len(flag),h4_refined=len(changed),label_changes_from_main=sum(r['label_changed_from_main'] for r in rows),unresolved_rows=sum(r['unresolved'] for r in rows),scope='Conditional distribution-specific scenario shares; intervals measure sampling precision only')
    write_json(dest/'summary.json',summary);print('STAGE7',json.dumps(summary),flush=True)
