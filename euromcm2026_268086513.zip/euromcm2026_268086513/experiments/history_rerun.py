import os
"""Reproduce the unchanged historical module and dense-grid table without refitting."""
import itertools,json,math,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/historical'))
from hominin_shared_test import run,alone_equilibrium,E_N
sys.path.insert(0,str(ROOT/'experiments'))
from common import write_json,write_csv,sha

def main():
    dest=Path(os.environ.get('V4_OUTPUT_ROOT',str(ROOT/'runs/full_reproduction')))/'history';started=time.time()
    write_json(dest/'RUN.json',dict(source_sha256=sha(ROOT/'src/historical/hominin_shared_test.py'),allocation_sha256=sha(ROOT/'src/historical/resource_allocation.py'),scope='Original historical parameter sets; no calibration; compare to imported saved evidence'))
    rows=[]
    for mode,de,r,mu in itertools.product(('equal_capture','priority'),(100.,225.,350.),(.001,.01),(1/37,1/35,1/21)):
        rows.append(run(de,r,mu,mode))
    saved=json.loads((ROOT/'reference/history_saved/hominin_shared_test.json').read_text())
    max_abs=0.;max_scaled=0.;bad=0
    for new,old in zip(rows,saved['rows']):
        for k in ('T10_90','clock_approx','solver_status'):
            if new[k] is None or old[k] is None:bad+=new[k]!=old[k];continue
            d=abs(new[k]-old[k]);max_abs=max(max_abs,d);max_scaled=max(max_scaled,d/max(1,abs(old[k])))
    # Same exact dense grid and record structure as the original plot entry.
    dense=[]
    for i,(mode,de,r,mu) in enumerate(itertools.product(('equal_capture','priority'),np.arange(100.,351.,10.),(.001,.01),(1/37,1/35,1/21))):
        x=run(de,r,mu,mode);dense.append({k:v for k,v in x.items() if k!='in_band'} | {f'in_{k.split()[0]}':v for k,v in x['in_band'].items()})
        if i%40==0:print('history',i,'/312 elapsed',round(time.time()-started,1),flush=True)
    old=pd.read_csv(ROOT/'reference/history_saved/hist_main_test.csv');new=pd.DataFrame(dense)
    assert len(old)==len(new)
    mism=[]
    for c in old.columns:
        if pd.api.types.is_numeric_dtype(old[c]) and not pd.api.types.is_bool_dtype(old[c]):
            x=old[c].to_numpy(float);y=new[c].to_numpy(float);finite=np.isfinite(x)&np.isfinite(y)
            if not np.array_equal(np.isfinite(x),np.isfinite(y)) or not np.allclose(x[finite],y[finite],rtol=1e-11,atol=1e-10):mism.append(c)
        elif not np.array_equal(old[c].astype(str),new[c].astype(str)):mism.append(c)
    density=[]
    for de,r in itertools.product((100.,225.,350.),(.001,.01)):
        em=1-de/E_N;kn=alone_equilibrium(1.,r,1/35);km=alone_equilibrium(em,r,1/35)
        density.append(dict(delta_e=de,r=r,K_M_over_K_N=km/kn,analytic_e_N_over_e_M=1/em))
    step=[run(225.,r,1/35,'equal_capture',max_step=2.5) for r in (.001,.01)]
    write_json(dest/'historical_small_grid.json',dict(rows=rows,density_each_alone=density,step_check=step))
    write_csv(dest/'historical_dense_grid.csv',dense)
    summary=dict(status='PASS' if bad==0 and max_scaled<1e-11 and not mism else 'FAIL',small_grid_rows=len(rows),dense_grid_rows=len(dense),max_abs_time_or_formula_difference=max_abs,max_scaled_difference=max_scaled,dense_mismatched_columns=mism,seconds=time.time()-started,
                 equality='Exact same numerical environment; JSON values compared numerically and CSV formatting allowed round-trip tolerance.',density_ratio_range=[min(x['K_M_over_K_N'] for x in density),max(x['K_M_over_K_N'] for x in density)],density_10_to_1_reproduced=False)
    write_json(dest/'summary.json',summary);print(json.dumps(summary),flush=True)
    if summary['status']!='PASS':raise SystemExit(1)
if __name__=='__main__':main()
