"""Explicit append-only full workflow for the accepted V4 equations.

Full scans are expensive. Release acceptance runs smoke and saved-data checks;
it does not falsely mark this entire workflow as dynamically rerun.
"""
import csv
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import numpy as np
from common import ROOT, HGRID, PGRID, SCEN, run, metrics, reference_params, write_json, write_csv
from fast_batch import jobs_run, decode

def refine_extinction(base):
    """Separate extinction avoidance from avoiding sustained marginalisation."""
    from release_checks import read
    rows=read(base/'stage5/thresholds_refined.csv'); evaluations=[]; endpoints=[]
    def extinct(r,a,h):
        job=[float(r['tau_H']),float(r['tau_phys']),a,float(r['T']),h,int(r['scenario']),0,0,1e100,1,0]
        m=decode(jobs_run([job])[0,1])
        evaluations.append(dict(scenario=r['scenario'],T=r['T'],tau_H=r['tau_H'],tau_phys=r['tau_phys'],a=a,h=h,label=m['label']))
        return m['label']=='quasi_extinction'
    for r in rows:
        a=float(r['a_grid_avoid_extinction']);lo=max(0.,a-.025);hi=a
        if a==0:
            r.update(a_ext_bracket_lower='0',a_ext_bracket_upper='0',a_ext_refinement='not_needed_zero_safe',a_ext_endpoint_h='')
            continue
        status='UNRESOLVED'
        for attempt in range(4):
            h=.0001953125/2**attempt
            while extinct(r,hi,h):
                if hi>=1:raise RuntimeError('Extinction at a=1 contradicts registered protection')
                hi=min(1.,hi+.025)
            while lo>0 and not extinct(r,lo,h):lo=max(0.,lo-.025)
            while hi-lo>.001:
                mid=(lo+hi)/2
                if extinct(r,mid,h):lo=mid
                else:hi=mid
            if extinct(r,lo,h/2) and not extinct(r,hi,h/2) and extinct(r,lo,h/4) and not extinct(r,hi,h/4):
                status='endpoint_verified_finer_steps_no_unsampled_reversal';break
        r.update(a_ext_bracket_lower=str(lo),a_ext_bracket_upper=str(hi),a_ext_refinement=status,a_ext_endpoint_h=str(h/4))
        endpoints.append(dict(scenario=r['scenario'],T=r['T'],tau_H=r['tau_H'],tau_phys=r['tau_phys'],lower=lo,upper=hi,valid=status!='UNRESOLVED'))
    # Preserve the intermediate safe-only table before writing the augmented table.
    (base/'stage5/thresholds_refined.csv').rename(base/'stage5/criterion_thresholds_before_extinction.csv')
    write_csv(base/'stage5/thresholds_refined.csv',rows)
    write_csv(base/'stage5/extinction_evaluations.csv',evaluations)
    write_csv(base/'stage5/EXTINCTION_BOUNDARY_ENDPOINT_CHECKS.csv',endpoints)
    write_json(base/'stage5/EXTINCTION_REFINEMENT.json',dict(status='PASS' if all(r['a_ext_refinement']!='UNRESOLVED' for r in rows) else 'FAIL',evaluations=len(evaluations)))
    if any(r['a_ext_refinement']=='UNRESOLVED' for r in rows):raise RuntimeError('Unresolved extinction brackets')

def scale_scan(base,growth):
    from scale_metrics import lane_metrics
    from v4model import Run
    from types import SimpleNamespace
    p0=reference_params();p0['g_E']=math.log(1.026) if growth else 0.
    th=np.r_[HGRID,[1.,2.,5.]]
    design=[(float(h),float(p),a) for h in th for p in PGRID for a in (0.,.5,.9)]
    output={100:{},200:{}}
    def evaluate(sc,h,indices):
        result={100:[],200:[]}
        for start in range(0,len(indices),54):
            ix=indices[start:start+54];keys=[design[i] for i in ix]
            p=dict(p0,mu=np.array([math.log(2)/v[0] for v in keys]),r_phys=np.array([p0['delta_A']+math.log(2)/v[1] for v in keys]))
            tr=run(p,[v[2] for v in keys],sc,200,h)
            for T in (100,200):
                stop=int(round(T/h))+1
                part=Run(tr.t[:stop],{k:v[:stop] for k,v in tr.rec.items()},tr.meta)
                baseline=SimpleNamespace(rec={'H':np.full_like(part.rec['H'],p0['H0'])})
                result[T]+=lane_metrics(part,baseline)
        return result
    for sc in SCEN:
        ids=list(range(len(design)));coarse=evaluate(sc,.0125,ids);fine=evaluate(sc,.00625,ids)
        flagged=[i for i in ids if any(abs(fine[T][i]['H_ratio_T']-.5)<.05 or coarse[T][i]['label']!=fine[T][i]['label'] or (fine[T][i]['first_quasi_extinction'] is not None and abs(fine[T][i]['first_quasi_extinction']-T)<1) for T in (100,200))]
        finer=evaluate(sc,.003125,flagged) if flagged else {100:[],200:[]}
        for T in output:
            extra=dict(zip(flagged,finer[T]));rows=[]
            for i,(c,f) in enumerate(zip(coarse[T],fine[T])):
                hh,pp,aa=design[i]
                stable=c['label']==f['label'] and (i not in extra or extra[i]['label']==f['label'])
                rows.append(dict(tau_H=hh,tau_phys=pp,a=aa,stress=hh<10-1e-9,**f,err_H_ratio=abs(c['H_ratio_T']-f['H_ratio_T']),label_h=c['label'],label_stable=stable,h4=extra.get(i),provenance='fresh_release_reproduction'))
            output[T][str(sc)]=rows
        print('scale completed',growth,sc,flush=True)
    for T in output:
        write_json(base/('stage22' if growth else 'stage4')/f'results_T{T}.json',dict(T=T,g_E=p0['g_E'],rows=output[T]))

def reproduce(base):
    """Run the modern stages, local refinements, scales, and historical test."""
    env=dict(os.environ,V4_TEST_OUTPUT=str(base/'validation'),V4_OUTPUT_ROOT=str(base))
    (base/'validation').mkdir()
    subprocess.run([sys.executable,'-B',str(ROOT/'tests/validate_backend.py')],env=env,check=True)
    # Gate ties the dynamic backend validation to precisely the current sources.
    gate=json.loads((base/'validation/BACKEND_VALIDATION.json').read_text())
    from common import sha
    if gate['status']!='PASS' or gate['model_sha256']!=sha(ROOT/'src/v4model.py') or gate['backend_sha256']!=sha(ROOT/'experiments/batch_kernel.cpp'):
        raise RuntimeError('Final-source backend gate failed')
    import production,refine_numerics
    production.BASE=base;refine_numerics.B=base
    for name in ('stage6','stage5','stage7'):
        getattr(production,name)()
    refine_numerics.alignment();refine_numerics.sampling();refine_extinction(base)
    scale_scan(base,False);scale_scan(base,True)
    subprocess.run([sys.executable,'-B',str(ROOT/'experiments/history_rerun.py')],env=env,check=True)
    from release_checks import verify_results
    (base/'verification').mkdir()
    verify_results(base,base/'verification')
    write_json(base/'WORKFLOW_COMPLETE.json',dict(status='PASS',note='All workflow stages completed and saved-table acceptance passed; delivered current results remain immutable.'))
