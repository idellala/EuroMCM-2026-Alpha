"""Selected dynamic checks against existing paper inputs, not a production rerun."""
import argparse
import json
import math
from pathlib import Path
import sys
import time
import numpy as np
import pandas as pd
from common import ROOT, CFG, SCEN, HGRID, PGRID, run, metrics, reference_params, sha
from v4model import simulate

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True);args=ap.parse_args()
    out=Path(args.output).resolve()
    if out.exists():raise FileExistsError('Use a new directory')
    out.mkdir(parents=True);started=time.time();checks=[];rows=[]
    p=reference_params();p.update(mu=math.log(2)/float(HGRID[0]),r_phys=p['delta_A']+math.log(2)/float(PGRID[0]))
    trajectory=pd.read_csv(ROOT/'data/representative_trajectories.csv')
    for sc in (1,2,3):
        tr=run(p,[0.],sc,200,.00625)
        for T in (100,200):
            saved=json.loads((ROOT/f'results/current/stage4/results_T{T}.json').read_text())['rows'][str(sc)]
            expected=next(r for r in saved if np.isclose(r['tau_H'],HGRID[0]) and np.isclose(r['tau_phys'],PGRID[0]) and r['a']==0.)
            actual=float(tr.rec['H'][int(round(T/.00625)),0]/p['H0'])
            error=abs(actual-expected['H_ratio_T'])
            checks.append(dict(name=f'S{sc}_T{T}_saved_population',status='PASS' if error<1e-11 else 'FAIL',absolute_error=error))
            rows.append(dict(scenario=sc,T=T,k_scope='all',saved=expected['H_ratio_T'],recomputed=actual,absolute_error=error))
        d=trajectory[trajectory.scenario==sc];ix=np.rint(d.t.to_numpy()/.00625).astype(int)
        errors={k:float(np.max(abs(tr.rec[field][ix,0]/factor-d[k].to_numpy()))) for k,field,factor in [('H_ratio','H',p['H0']),('q','q',1.),('m_run','A_run',p['E0_ref'])]}
        checks.append(dict(name=f'Figure4_saved_samples_S{sc}',status='PASS' if max(errors.values())<1e-11 else 'FAIL',absolute_errors=errors))
    # Exact saved representative diagnostics, no new design or parameter choices.
    saved=pd.read_csv(ROOT/'results/current/K_SCOPE_COMPARISON.csv')
    representative=saved[(saved['T']==200)&(saved.a==0)&np.isclose(saved.tau_H,HGRID[0])&np.isclose(saved.tau_phys,PGRID[0])&(saved.k_scope=='autonomous')&saved.scenario.isin([1,3])]
    if len(representative)!=2:raise RuntimeError('Missing registered K representative rows')
    for _,r in representative.iterrows():
        sc=int(r.scenario);tr=simulate(p,[0.],*SCEN[sc],T=200,h=.00625,**dict(CFG,k_scope='autonomous'))
        actual=metrics(tr,p)[0];err=abs(actual['H_ratio_T']-r.H_ratio_T)
        checks.append(dict(name=f'K_scope_S{sc}',status='PASS' if err<1e-11 and actual['label']==r.label else 'FAIL',absolute_error=err))
        rows.append(dict(scenario=sc,T=200,k_scope='autonomous',saved=r.H_ratio_T,recomputed=actual['H_ratio_T'],absolute_error=err))
    curves=pd.read_csv(ROOT/'results/current/stage5/alignment_curves.csv')
    atlas=curves[np.isclose(curves.tau_phys,3)&curves.scenario.isin([1,2])]
    expected={(1,100):(367,125,0),(2,100):(315,157,20),(1,200):(273,219,0),(2,200):(174,242,76)}
    for (sc,T),counts in expected.items():
        g=atlas[(atlas.scenario==sc)&(atlas['T']==T)]
        actual=tuple(int(sum(g.label==label)) for label in ('normal','marginal','quasi_extinction'))
        checks.append(dict(name=f'Atlas_counts_S{sc}_T{T}',status='PASS' if actual==counts else 'FAIL',actual=actual,expected=counts))
    pd.DataFrame(rows).to_csv(out/'DYNAMIC_COMPARISONS.csv',index=False)
    result=dict(status='PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL',checks=checks,seconds=time.time()-started,
                model_sha256=sha(ROOT/'src/v4model.py'),entry_sha256=sha(Path(__file__)),step=.00625,
                scope='Five 200-year representative trajectories: S1/S2/S3 main and S1/S3 autonomous-only K; six main horizon values and three sampled Figure-4 series compared. Atlas checks reaggregate saved rows. No full experiment rerun.')
    (out/'PAPER_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    if result['status']!='PASS':raise SystemExit(1)

if __name__=='__main__':main()
