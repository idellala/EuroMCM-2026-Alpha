"""Validated numerical backend; matches the repaired Python reference."""
import ctypes
import json
import subprocess
import os
import shutil
import sys
from pathlib import Path
import numpy as np
from common import ROOT, reference_params

FIELDS=['H_ratio_T','H_T','A_g','A_s','C','I','min_q','q_T','deficit_years','max_m_run','max_m_installed','t_eta','first_quasi_extinction','label_code','conservation_residual','population_identity_error','first_cross_raw','grid_share_T','m_E_T','m_run_T']
LABELS=['normal','marginal','quasi_extinction']
PARAMS=['H0','E0_avail','L0_avail','e_n','ell_n','eps','F','delta_A','r_A0','G_hw','g','C_max','kappa','chi','A_ref','lambda_dc','lambda_gen','L_other','H_ext','eta','W','f']
LIB=None

def load():
 global LIB
 if LIB is None:
  dest=ROOT/'build';dest.mkdir(exist_ok=True);src=Path(__file__).with_name('batch_kernel.cpp');lib=dest/('batch_kernel.dylib' if sys.platform == 'darwin' else 'batch_kernel.so')
  if not lib.exists() or lib.stat().st_mtime<src.stat().st_mtime:
   compiler=os.environ.get('CXX') or shutil.which('clang++') or shutil.which('g++')
   if not compiler:raise RuntimeError('Full reproduction requires clang++ or g++; Python simulation does not.')
   cmd=[compiler,'-std=c++17','-O3','-ffp-contract=off','-shared','-fPIC',str(src),'-o',str(lib)]
   r=subprocess.run(cmd,capture_output=True,text=True);(dest/'compile.log').write_text(r.stdout+r.stderr)
   if r.returncode:raise RuntimeError('Backend compilation failed')
  LIB=ctypes.CDLL(str(lib));ptr=ctypes.POINTER(ctypes.c_double)
  LIB.batch.argtypes=[ctypes.c_int,ptr,ptr,ptr];LIB.batch.restype=None
 return LIB

def jobs_run(jobs,p=None):
 """Rows: tau_H,tau_phys,a,T,h,scenario,kind,tau,cap,phi,g_E."""
 j=np.ascontiguousarray(jobs,dtype=np.float64).reshape(-1,11)
 if np.any(~np.isin(j[:,3],[100.,200.])):raise ValueError('Backend supports registered T=100/200 only')
 p=reference_params() if p is None else p
 a=np.ascontiguousarray([p[x] for x in PARAMS],dtype=np.float64)
 o=np.zeros((len(j),2,20));ptr=ctypes.POINTER(ctypes.c_double)
 load().batch(len(j),a.ctypes.data_as(ptr),j.ctypes.data_as(ptr),o.ctypes.data_as(ptr))
 if not np.all(np.isfinite(o)):raise FloatingPointError('Nonfinite backend output')
 return o

def decode(row):
 d=dict(zip(FIELDS,map(float,row)));d['label']=LABELS[int(d.pop('label_code'))]
 for k in ('t_eta','first_quasi_extinction','first_cross_raw'):
  if d[k]<0:d[k]=None
 d['deficit_people']=reference_params()['H0']-d['H_T']
 return d
