import argparse
import json
import math
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import ROOT, SCEN, HGRID, PGRID, metrics, reference_params, run, sha, write_json, write_csv
import numpy as np

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');ap.add_argument('--run-id',required=True)
    args=ap.parse_args();dest=ROOT/'results/stage6'/args.run_id
    if dest.exists():raise FileExistsError(dest)
    dest.mkdir(parents=True)
    write_json(dest/'design.json',dict(quick=args.quick,model_sha256=sha(ROOT/'src/v4model.py'),prereg_sha256=sha(Path(__file__).with_name('README.md')),started_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()))
    allrows=[];weights=[];started=time.time()
    for T in ([100] if args.quick else [100,200]):
        points=[(HGRID[0],PGRID[0])] if args.quick else [(h,p) for h in HGRID[[0,4,8]] for p in PGRID[[0,4,8]]]
        av=np.array([0.,.9]) if args.quick else np.array([0.,.5,.9])
        times=[0.,50.,100.] if args.quick else np.linspace(0,T,21).tolist()
        caps=[415.] if args.quick else [41.5,415.,945.,3125.6]
        for scenario in ([1,2] if args.quick else SCEN):
            for th,tp in points:
                p=reference_params();p.update(mu=math.log(2)/th,r_phys=p['delta_A']+math.log(2)/tp)
                baseline={}
                Iat={}
                for h in (.0125,.00625):
                    tr=run(p,av,scenario,T,h);baseline[h]=metrics(tr,p)
                    for tau in times:
                        ix=int(np.argmin(abs(tr.t-tau)))
                        if abs(tr.t[ix]-tau)>1e-10:raise RuntimeError('missing intervention grid time')
                        Iat[(h,tau)]=tr.rec['I'][ix].copy()
                for kind,cap in [('cap',c) for c in caps]+[('shutdown_success',None)]:
                    for tau in times:
                        pol=dict(kind='cap',tau=tau,cap=cap) if kind=='cap' else dict(kind='shutdown',tau=tau,success=True)
                        mm={}
                        for h in (.0125,.00625):
                            mm[h]=metrics(run(p,av,scenario,T,h,pol),p)
                        flagged=any(abs(x['H_ratio_T']-.5)<.05 or x['label']!=y['label'] for x,y in zip(mm[.00625],mm[.0125]))
                        fine=metrics(run(p,av,scenario,T,.003125,pol),p) if flagged else None
                        for j,a in enumerate(av):
                            b=baseline[.00625][j];m=mm[.00625][j];coarse=mm[.0125][j]
                            err=abs(m['H_ratio_T']-coarse['H_ratio_T']);berr=abs(b['H_ratio_T']-baseline[.0125][j]['H_ratio_T'])
                            row=dict(T=T,scenario=scenario,tau_H=float(th),tau_phys=float(tp),a=float(a),kind=kind,cap=cap,tau=float(tau),**m,
                                     baseline_label=b['label'],baseline_H_ratio=b['H_ratio_T'],gain_H_ratio=m['H_ratio_T']-b['H_ratio_T'],err_H_ratio=err,
                                     gain_numerically_resolved=abs(m['H_ratio_T']-b['H_ratio_T'])>3*(err+berr),label_stable=coarse['label']==m['label'],
                                     h4_label=None if fine is None else fine[j]['label'],h4_H_ratio=None if fine is None else fine[j]['H_ratio_T'])
                            allrows.append(row)
                            if not row['label_stable'] and fine is None:raise RuntimeError('unresolved branch label')
                            if m['population_identity_error']>1e-9:raise RuntimeError('population identity failed')
                            if kind=='shutdown_success':
                                for p0 in (.5,.9,1.):
                                    prob=float(p0*(1-Iat[(.00625,tau)][j]));wc={label:prob*(m['label']==label)+(1-prob)*(b['label']==label) for label in ('normal','marginal','quasi_extinction')}
                                    weights.append(dict(T=T,scenario=scenario,tau_H=float(th),tau_phys=float(tp),a=float(a),tau=float(tau),p0=p0,p_success=prob,
                                                        weighted_H_ratio=prob*m['H_ratio_T']+(1-prob)*b['H_ratio_T'],success_H_ratio=m['H_ratio_T'],failure_H_ratio=b['H_ratio_T'],
                                                        success_label=m['label'],failure_label=b['label'],**{'weight_'+k:v for k,v in wc.items()}))
                        print('stage6',T,scenario,round(float(th),4),round(float(tp),4),kind,cap,tau,'elapsed',round(time.time()-started,1),flush=True)
                write_json(dest/f'checkpoint_T{T}_s{scenario}_h{float(th):.8g}_p{float(tp):.8g}.json',dict(rows=[r for r in allrows if r['T']==T and r['scenario']==scenario and r['tau_H']==float(th) and r['tau_phys']==float(tp)]))
    write_csv(dest/'branches.csv',allrows);write_csv(dest/'shutdown_weights.csv',weights)
    groups={}
    for row in allrows:
        key=tuple(row[k] for k in ('T','scenario','tau_H','tau_phys','a','kind','cap'))
        groups.setdefault(key,[]).append(row)
    deadlines=[]
    for key,rs in groups.items():
        rs=sorted(rs,key=lambda r:r['tau']);safe=[r['label']=='normal' for r in rs]
        monotone=not any((not safe[i]) and safe[i+1] for i in range(len(safe)-1))
        baseline_normal=rs[0]['baseline_label']=='normal'
        stable=all(r['label_stable'] and (r['h4_label'] is None or r['h4_label']==r['label']) for r in rs)
        times=[r['tau'] for r in rs if r['label']=='normal']
        deadlines.append(dict(zip(('T','scenario','tau_H','tau_phys','a','kind','cap'),key),
                              baseline_already_normal=baseline_normal,labels_numerically_stable=stable,
                              safe_time_set=times,monotone_on_sampled_times=monotone,
                              last_sampled_effective_time=max(times) if times and monotone and stable and not baseline_normal else None,
                              note='Sampled branch deadline; not a continuous bound or weighted-shutdown guarantee.'))
    write_json(dest/'sampled_deadlines.json',deadlines)
    summary=dict(mode='preflight' if args.quick else 'production',branch_rows=len(allrows),weight_rows=len(weights),seconds=time.time()-started,
                 max_identity_error=max(r['population_identity_error'] for r in allrows),label_disagreements=sum(not r['label_stable'] for r in allrows))
    write_json(dest/'summary.json',summary);print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
