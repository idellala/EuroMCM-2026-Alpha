# Registered intervention experiment

Registered before the new intervention runs. Frozen model and CFG are unchanged.
Primary design: fixed grid, all four scenarios; T=100,200; exact indices 0,4,8
of each original time-scale grid; a=0,0.5,0.9. Intervention times are 0..T in
21 equally spaced points. Caps are 41.5,415,945,3125.6 TWh/year. Shutdown is
simulated only for the successful branch; its failed branch is exactly baseline.
p0=0.5,0.9,1 are applied afterwards with p_success=p0*(1-I(tau-minus)).
No classification of expected population is performed.

Each point runs h=0.0125 and h/2. Label disagreement or near marginalisation
triggers h/4. Output includes branch results, label stability, population
differences and numerical comparisons, conditional normal weights, and scale.
The operational cap also affects construction through the frozen K rule.

Last effective times refer to deterministic cap/successful-shutdown branches.
If sampled effectiveness is nonmonotonic, retain the time set instead. A time
grid only gives a sampled deadline, not a continuous last-rescue time. A baseline
already normal is reported separately, not claimed as a successful rescue.
Shutdown can leave land unavailable while retained structures retire. There is
no requirement that its deadline equal the no-policy crossing time.

Preflight (--quick): scenarios 1,2, tau_H=main[0], tau_phys=main[0], a=0,0.9,
T=100, tau=0,50,100, cap=415. Same h/h2 verification; not the production design.
This tests both intervention types, both branches and both supply structures.

Unexpected results are retained. The run stops only on implementation failure.
