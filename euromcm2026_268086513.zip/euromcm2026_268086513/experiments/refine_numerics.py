import os
import csv,json,math,sys,collections,time
from pathlib import Path
import numpy as np
from common import ROOT,write_json,write_csv
from fast_batch import jobs_run,decode
B=Path(os.environ.get('V4_OUTPUT_ROOT',str(ROOT/'runs/full_reproduction')));START=time.time()

def read(rel):return list(csv.DictReader((B/rel).open()))
def zrow(r,a,h):return [float(r['tau_H']),float(r['tau_phys']),a,float(r['T']),h,int(r['scenario']),0.,0.,1e100,1.,0.]
def pair(jobs):
 f=jobs_run(jobs);c=jobs_run([z[:4]+[z[4]*2]+z[5:] for z in jobs]);return f,c

def alignment():
 rows=read('stage5/thresholds.csv');curve=read('stage5/alignment_curves.csv');unstable={(r['scenario'],r['tau_H'],r['tau_phys'],r['T']) for r in curve if r['label_stable']!='True'}
 corrections=[];evals=[]
 for r in rows:
  key=tuple(r[k] for k in ('scenario','tau_H','tau_phys','T'))
  if key not in unstable:continue
  av=np.linspace(0,1,41);f,c=pair([zrow(r,a,.00078125) for a in av]);codes=f[:,1,13].astype(int)
  if np.any(f[:,1,13]!=c[:,1,13]):raise RuntimeError('Grid profile still unstable after local refinement')
  idx=next(i for i in range(41) if np.all(codes[i:]==0));r['a_grid_avoid_extinction']=str(float(av[next(i for i in range(41) if np.all(codes[i:]!=2))]));r['a_grid_safe']=str(float(av[idx]));r['bracket_lower']=str(float(av[max(0,idx-1)]));r['bracket_upper']=r['a_grid_safe'];r['grid_labels_stable']='True'
  for a,ff,cc in zip(av,f,c):corrections.append(dict(scenario=int(r['scenario']),tau_H=float(r['tau_H']),tau_phys=float(r['tau_phys']),T=int(r['T']),a=float(a),**decode(ff[1]),h=.00078125,label_stable=True,err_H_ratio=float(abs(ff[1,0]-cc[1,0]))))
 active=[]
 for i,r in enumerate(rows):
  if float(r['a_grid_safe'])>0 and r['upward_closed_on_grid']=='True' and r['population_monotone_within_error']=='True':
   r['bracket_lower']=str(float(r['a_grid_safe'])-.025);r['bracket_upper']=r['a_grid_safe'];active.append(i)
  else:r['refinement_status']='not_needed' if float(r['a_grid_safe'])==0 else 'not_refined'
 for iteration in range(5):
  jobs=[zrow(rows[i],(float(rows[i]['bracket_lower'])+float(rows[i]['bracket_upper']))/2,.00078125) for i in active]
  fine,coarse=pair(jobs);next_active=[]
  for j,i in enumerate(active):
   r=rows[i];ff=fine[j];cc=coarse[j];h=jobs[j][4];level=0
   while ff[1,13]!=cc[1,13] and level<6:
    h/=2;ff2,cc2=pair([jobs[j][:4]+[h]+jobs[j][5:]]);ff,cc=ff2[0],cc2[0];level+=1
   stable=ff[1,13]==cc[1,13];a=jobs[j][2]
   evals.append(dict(scenario=r['scenario'],tau_H=r['tau_H'],tau_phys=r['tau_phys'],T=r['T'],a=a,h=h,label_fine=decode(ff[1])['label'],label_coarse=decode(cc[1])['label'],stable=bool(stable),H_error=float(abs(ff[1,0]-cc[1,0]))))
   if not stable:r['refinement_status']='unresolved_numeric_boundary';continue
   if ff[1,13]==0:r['bracket_upper']=str(a)
   else:r['bracket_lower']=str(a)
   r['refinement_status']='estimated_bracket_step_stable_assuming_no_unsampled_reversal';r['smallest_refinement_h']=str(h)
   if float(r['bracket_upper'])-float(r['bracket_lower'])>.001:next_active.append(i)
  active=next_active;print('alignment refinement',iteration,'remaining',len(active),'elapsed',round(time.time()-START,1),flush=True)
  if not active:break
 write_csv(B/'stage5/thresholds_refined.csv',rows);write_csv(B/'stage5/grid_corrections.csv',corrections);write_csv(B/'stage5/refinement_evaluations.csv',evals)
 write_json(B/'stage5/refinement_summary.json',dict(profiles=len(rows),corrected_grid_profiles=len(unstable),grid_correction_rows=len(corrections),evaluations=len(evals),remaining_unresolved=sum(r['refinement_status']=='unresolved_numeric_boundary' for r in rows),max_positive_bracket_width=max(float(r['bracket_upper'])-float(r['bracket_lower']) for r in rows if float(r['a_grid_safe'])>0),seconds=time.time()-START))

def sampling():
 rows=read('stage7/sample_results.csv');targets={}
 for r in rows:
  if abs(float(r['H_ratio_T'])-.9)<.01:targets[(r['prior'],r['scenario'],r['a'],r['sample'])]=r
 jobs=[zrow(dict(r,T='200'),float(r['a']),.003125) for r in targets.values()];fine,coarse=pair(jobs);lookup=dict(zip(targets,zip(fine,coarse)));changes=0;unresolved=0
 for r in rows:
  key=(r['prior'],r['scenario'],r['a'],r['sample'])
  if key not in lookup:continue
  f,c=lookup[key];slot=0 if int(r['T'])==100 else 1;m=decode(f[slot]);old=r['category'];new=m['label'] if m['label']!='normal' else ('normal_loss_ge_10pct' if m['H_ratio_T']<.9 else 'normal_loss_lt_10pct')
  coarse_cat=decode(c[slot])['label'] if c[slot,13]!=0 else ('normal_loss_ge_10pct' if c[slot,0]<.9 else 'normal_loss_lt_10pct');bad=new!=coarse_cat
  changes+=new!=old;unresolved+=bad;r.update(m,category=new,refined=True,unresolved=bad,reporting_category_audited=True)
 groups=collections.defaultdict(list)
 for r in rows:groups[(r['prior'],r['scenario'],r['a'],r['T'])].append(r)
 from production import wilson
 stats=[]
 for key,rr in groups.items():
  prior,sc,a,T=key
  for cat in ('quasi_extinction','marginal','normal_loss_ge_10pct','normal_loss_lt_10pct'):
   k=sum(r['category']==cat for r in rr);n=len(rr);lo,hi=wilson(k,n);rat=[float(r['H_ratio_T']) for r in rr]
   stats.append(dict(prior=prior,scenario=int(sc),a=float(a),T=int(T),category=cat,n=n,count=k,conditional_share=k/n,wilson95_low=lo,wilson95_high=hi,MCSE=math.sqrt((k/n)*(1-k/n)/n),H_q05=float(np.quantile(rat,.05)),H_q50=float(np.quantile(rat,.5)),H_q95=float(np.quantile(rat,.95)),unresolved=sum(str(r['unresolved']) in ('True','true') for r in rr)))
 write_csv(B/'stage7/sample_results_audited.csv',rows);write_csv(B/'stage7/conditional_shares_audited.csv',stats)
 write_json(B/'stage7/reporting_cut_audit.json',dict(additional_T200_trajectories=len(jobs),category_changes=changes,category_unresolved_rows=unresolved,post_run_validation=True))

# Called explicitly by the release reproduction entry point.
