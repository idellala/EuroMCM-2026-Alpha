"""Retained scale diagnostics; equations unchanged, imported explicitly."""
import numpy as np
from v4model import reference_params
from outcomes_delivered import classify_arrays
P=reference_params(); E0REF=P['E0_ref']; MULT=(1,10,30,100)
CLS=dict(H0=P['H0'],H_ext=P['H_ext'],eta=P['eta'],W=P['W'],q_bar=.5)

def first_t(t, mask):
    i = np.flatnonzero(mask)
    return (None, None) if len(i) == 0 else (float(t[i[0]]), int(i[0]))


def lane_metrics(r, b):
    out = []
    R, B = r.rec, b.rec; t = r.t
    ratio_all = R['H'] / B['H']
    mrun_all = (R['A_g_run'] + R['A_s']) / E0REF; minst_all = (R['A_g'] + R['A_s']) / E0REF
    for j in range(ratio_all.shape[1]):
        ratio = ratio_all[:, j]; mrun = mrun_all[:, j]; minst = minst_all[:, j]
        cl = classify_arrays(t, ratio * P['H0'], np.ones_like(ratio), CLS)
        ent = cl['first_marginal_entry']
        x = dict(H_ratio_T=float(ratio[-1]), deficit_people=float(B['H'][-1, j] - R['H'][-1, j]),
                 min_q=float(np.nanmin(R['q'][:, j])), q_T=float(R['q'][-1, j]),
                 grid_share_T=float(R['A_g_run'][-1, j] / R['E'][-1, j]), A_run_T=float(R['A_run'][-1, j]),
                 first_cross_eta=None if ent is None else ent - P['W'], first_quasi_extinction=cl['first_quasi_extinction'], label=cl['label'],
                 H_T=float(R['H'][-1, j]), residual=r.meta['max_conservation_residual'])
        # --- §12 scale diagnostics (descriptive signposts) ---
        x['max_m_run'] = float(mrun.max()); x['max_m_installed'] = float(minst.max()); x['m_run_T'] = float(mrun[-1])
        x['t_m'] = {str(k): first_t(t, mrun >= k)[0] for k in MULT}
        for lev in (.99, .9):
            tl, il = first_t(t, ratio < lev)
            x[f't_ratio_below_{lev:g}'] = tl; x[f'm_run_at_ratio_below_{lev:g}'] = None if il is None else float(mrun[il])
        x['t_eta'] = x['first_cross_eta']; x['m_run_at_eta'] = x['m_installed_at_eta'] = None; x['constraint_at_eta'] = None
        if ent is not None:
            k = int(np.flatnonzero(t >= ent - P['W'] - 1e-12)[0]); k = max(k, 1)
            x['m_run_at_eta'] = float(mrun[k]); x['m_installed_at_eta'] = float(minst[k])
            human = 'none' if R['q'][k, j] >= 1 else ('land' if R['q_is_L'][k, j] else 'electricity')
            planned, unreal = R['planned_total'][k, j], R['unrealised'][k, j]
            if unreal <= 1e-9 * planned:
                build = ['build_capacity']
            else:
                build = []
                if R['land_limited'][k, j]: build.append('land')
                if R['A_g'][k, j] >= (R['E'][k - 1, j] - R['P_E'][k - 1, j]) * (1 - 1e-9): build.append('screen_K')
                if not build: build = ['other']
            x['constraint_at_eta'] = dict(t_grid=float(t[k]), human=human, q=float(R['q'][k, j]), build=build,
                                          unrealised_frac=float(unreal / planned) if planned > 0 else None,
                                          rsi_grid_share=float(R['A_g_run'][k, j] / R['E'][k, j]))
        out.append(x)
    return out

