# 来源状态与参数解释

本表合并此前审查记录；本轮是代码与结果交付整理，没有重新联网核对全部原文。
不要把旧文献档案中的待核状态当作当前全部状态，也不要把此前核对说成本轮新核对。

|对象|已有核对状态|不能由此推出的内容|
|---|---|---|
|FAO 2022 农业用地 4,781 百万 ha|此前独立审查记录已对照 FAO 官方页；换算 47,810,000 km²|全部可建设土地都必须来自农业地|
|EI 2025 全球发电量 31,255.9 TWh、十年平均增速 2.6%|此前独立审查记录已对照 EI 官方 PDF|未来两百年可持续按相同比率增长|
|IEA 当前终端能源用电比例约 20%|此前官方页核对|电力在所有关键服务上具有相同可替代性|
|Lovering 发电用地强度|此前原文核对及独立审查记录；光伏中位数约 2,000 ha/(TWh/年)|同一强度适用于全部未来技术、或包含全部上游制造输电占地|
|IEA 数据中心 415/945 TWh|官方赛题给定锚点|可据此校准未知 RSI 制造能力与资源需求|
|历史能耗、共存和密度|官方赛题给定范围，部分有争议|历史能验证未来 RSI 或提供现代人口响应系数|
|现代 μ、κ、f、K 规则等|情景/结构假设|已经由文献直接测量和校准|

已有来源定位：

- FAO: https://www.fao.org/statistics/highlights-archive/highlights-detail/land-statistics-2001-2022.-global--regional-and-country-trends/
- EI: https://www.energyinst.org/__data/assets/pdf_file/0007/1658077/Statistical-Review-of-World-Energy.pdf
- IEA: https://www.iea.org/reports/world-energy-outlook-2024/pathways-for-the-energy-mix
- Lovering et al.: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0270155

更多文献的原始核对记录在 reference/spec_history/LITERATURE_VERIFIED_CN.md；该文件保留修订前状态以供追溯。逆预期寿命不是短缺响应系数的直接校准，历史工业增长率仅作情景量级参照。
不得将第三方论文 PDF 视为本项目可重新许可的资产，本包不包含它们。
