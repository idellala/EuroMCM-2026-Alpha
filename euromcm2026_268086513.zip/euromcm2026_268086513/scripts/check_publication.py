"""Write or verify the current release inventory; historical receipts are immutable.

FILE_MANIFEST.csv intentionally does not hash itself. Run records and prior source
registries retain the hashes of the version actually executed at that time.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SKIP={'.git','.venv','__pycache__','.cache','build','runs'}

def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name!='.DS_Store'
                  and not any(x in SKIP for x in p.relative_to(ROOT).parts))

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--write',action='store_true',help='Refresh only CURRENT source registry and file inventory')
    args=ap.parse_args()
    ps=files();source=[p for p in ps if p.suffix in ('.py','.cpp') and (p==ROOT/'run.py' or p.relative_to(ROOT).parts[0] in {'src','experiments','scripts','tests','supplements'})]
    registry={str(p.relative_to(ROOT)):sha(p) for p in source}
    rp=ROOT/'config/RELEASE_SOURCES.json';mp=ROOT/'FILE_MANIFEST.csv'
    if args.write:
        rp.write_text(json.dumps(registry,indent=2)+'\n')
        with mp.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=['path','bytes','sha256','role']);w.writeheader()
            for p in files():
                if p==mp:continue
                rel=p.relative_to(ROOT);role='historical evidence' if rel.parts[0] in {'reference','evidence'} else 'current publication material'
                w.writerow(dict(path=str(rel),bytes=p.stat().st_size,sha256=sha(p),role=role))
    actual=json.loads(rp.read_text());errors=[]
    if actual!=registry:errors.append('current_source_registry_mismatch')
    rows=list(csv.DictReader(mp.open()));listed={r['path'] for r in rows}
    for r in rows:
        p=ROOT/r['path']
        if not p.is_file() or p.stat().st_size!=int(r['bytes']) or sha(p)!=r['sha256']:errors.append(r['path'])
    expected={str(p.relative_to(ROOT)) for p in files() if p!=mp}
    if expected!=listed:errors.append(dict(unlisted=sorted(expected-listed),missing=sorted(listed-expected)))
    print(json.dumps(dict(status='PASS' if not errors else 'FAIL',files=len(rows)+1,current_sources=len(registry),errors=errors,scope='Current manifest excludes itself and transient output directories. Historical hashes were not rewritten.'),indent=2))
    if errors:raise SystemExit(1)

if __name__=='__main__':main()
