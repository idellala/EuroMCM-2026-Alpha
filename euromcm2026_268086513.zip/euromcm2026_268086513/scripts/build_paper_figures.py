"""Replot the nine figures actually called by paper editing version v8.

This command reads delivered results. It does not rerun the experiment grids.
Figures 1 and 2 are editable mechanism schematics, not observations.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / 'build/mplconfig'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Patch
from matplotlib.lines import Line2D
from matplotlib.ticker import NullLocator
from scipy.optimize import brentq
sys.path.insert(0, str(ROOT / 'experiments'))
from common import reference_params

P = reference_params()
INK = '#3E2335'
COL = {1: '#355F8D', 2: '#B5577D', 3: '#578773', 4: '#9D789D'}
NAMES = {1: 'S1: shared grid', 2: 'S2: self-supply', 3: 'S3: substitutable energy', 4: 'S4: substitution + self-supply'}
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
    'axes.spines.top': False, 'axes.spines.right': False,
    'legend.frameon': False, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
    'axes.labelcolor': INK, 'text.color': INK, 'savefig.facecolor': 'white'})

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def edges(x, log=False):
    x = np.asarray(x, dtype=float)
    z = np.log(x) if log else x
    mid = (z[1:] + z[:-1]) / 2
    out = np.r_[2*z[0]-mid[0], mid, 2*z[-1]-mid[-1]]
    return np.exp(out) if log else out

def box(ax, x, y, w, h, text):
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.04',
                              linewidth=.8,edgecolor='#CDA9B8',facecolor='#FDF6F8'))
    ax.text(x,y,text,ha='center',va='center',fontsize=10)

def arrow(ax, a, b, dashed=False):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='->',mutation_scale=12,
                               color='#B5577D',lw=1.2,linestyle='--' if dashed else '-'))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',required=True)
    ap.add_argument('--results',default=str(ROOT/'results/current'))
    args=ap.parse_args()
    R=Path(args.results).resolve();out=Path(args.output).resolve()
    if R != (ROOT/'results/current').resolve():
        raise ValueError('Final-paper replot uses the frozen paper inputs only. This command uses delivered paper inputs; do not mix trajectory/supplement revisions.')
    if out.exists():raise FileExistsError('Choose a new output directory')
    out.mkdir(parents=True);(out/'data').mkdir()
    metadata=json.loads((ROOT/'paper/FIGURE_REFERENCE.json').read_text())
    records=[];sources={};analytic=[]
    def save(fig, num, title, data, inputs, detail):
        stem=f'Figure_{num:02d}'
        fig.canvas.draw()
        for ext in ('pdf','png','svg'):
            kwargs={'dpi':240} if ext=='png' else {}
            fig.savefig(out/(stem+'.'+ext),bbox_inches='tight',pad_inches=.1,**kwargs)
        if data is not None:data.to_csv(out/'data'/(stem+'.csv'),index=False)
        for p in inputs:sources[str(p.relative_to(ROOT))]=sha(p)
        reference=metadata['figures'][num-1]
        records.append(dict(figure=num,title=title,label=reference['label'],
                            paper_reference=reference['paper_reference'],source_page=reference['page'],
                            outputs=[stem+'.pdf',stem+'.png',stem+'.svg'],
                            data=None if data is None else 'data/'+stem+'.csv',
                            rows=0 if data is None else len(data),
                            input_paths=[str(p.relative_to(ROOT)) for p in inputs],
                            kind=reference['kind'],method=detail,
                            status='RENDERED_FROM_SAVED_EVIDENCE' if data is not None else 'REGENERATED_SCHEMATIC'))
        plt.close(fig);print('Rendered',stem,flush=True)

    # 1: semantic re-render of the exact inline TikZ workflow, retained in LaTeX.
    fig,ax=plt.subplots(figsize=(10,3.1));ax.set(xlim=(0,10),ylim=(0,3));ax.axis('off')
    for x,t in zip((1.2,3.7,6.2,8.7),('Evidence\nElectricity and land\nHistorical ranges','Resource core\nClaims -> adequacy\nPopulation response','Physical RSI\nInfrastructure\nGrowth and autonomy','Analysis\nFates and alignment\nIntervention timing')):
        box(ax,x,2,2.1,1.1,t)
    for x in (2.3,4.8,7.3):arrow(ax,(x,2),(x+.3,2))
    box(ax,2.6,.55,4.3,.65,'Historical check tests the common structure')
    box(ax,7.45,.55,4.3,.65,'Sensitivity qualifies the conclusions')
    arrow(ax,(3.7,1.4),(2.6,.92),True);arrow(ax,(8.7,1.4),(7.45,.92),True)
    save(fig,1,'Research workflow',None,[ROOT/'figures/source/workflow.tex'],
         'Schematic, editable Python/SVG plus original inline TikZ; no numeric evidence or new calculation.')

    # 2: schematic explicitly separates electricity flows from occupied land.
    fig,ax=plt.subplots(figsize=(10,4.9));ax.axis('off');ax.set(xlim=(0,10),ylim=(0,5))
    box(ax,1.25,2.5,2.1,1.3,'Population H\nResponse to shortage\nSets current demand')
    box(ax,4.65,3.8,3.0,1.1,'Electricity E (flow)\nProtect P_E first\nShare the rest by claims')
    box(ax,4.65,1.1,3.0,1.1,'Land L (stock)\nFacilities retain occupied land\nRelease only on retirement')
    box(ax,8.45,2.5,2.5,1.25,'Bottleneck adequacy\nq = min(1, q_E, q_L)\nDrives population response')
    arrow(ax,(2.35,2.8),(3.1,3.65));arrow(ax,(2.35,2.2),(3.1,1.25))
    arrow(ax,(6.2,3.65),(7.15,2.85));arrow(ax,(6.2,1.25),(7.15,2.15))
    ax.text(2.7,3.65,'D_E',fontsize=9);ax.text(2.7,1.25,'D_L',fontsize=9)
    ax.text(6.5,3.65,'E_H',fontsize=9);ax.text(6.5,1.25,'L_H',fontsize=9)
    ax.plot([8.45,8.45,1.25],[1.83,.4,.4],color=COL[2],lw=1.1)
    arrow(ax,(1.25,.4),(1.25,1.78))
    ax.text(5,.1,'RSI claims electricity; installed facilities occupy land. Population changes both demands.',ha='center',fontsize=9)
    save(fig,2,'Resources, claims and the population feedback',None,[ROOT/'docs/MODEL_CN.md'],
         'Mechanism schematic rebuilt from the stated equations; original graphical authoring script was not found. This editable schematic is a semantic re-render; no original PDF is copied as reproduction.')

    # 3: historical times plus the explicitly unsuccessful density check.
    hp=R/'history/historical_dense_grid.csv';sp=R/'history/historical_small_grid.json'
    hist=pd.read_csv(hp);density=pd.DataFrame(json.loads(sp.read_text())['density_each_alone'])
    fig,axs=plt.subplots(1,3,figsize=(10.2,3.5),layout='constrained')
    for ax,mode,title in zip(axs[:2],('equal_capture','priority'),('a  Equal per-capita capture','b  Newcomer priority')):
        ax.axhspan(2600,5400,color='#B8CBD9',alpha=.5);ax.axhspan(1400,2900,color='#E7D6AD',alpha=.5)
        for rate,ls in ((.001,'--'),(.01,'-')):
            d=hist[(hist.phi_mode==mode)&np.isclose(hist.r,rate)]
            mid=d[np.isclose(d.mu,1/35)].sort_values('delta_e');band=d.groupby('delta_e').T10_90.agg(['min','max'])
            ax.fill_between(band.index,band['min'],band['max'],color=COL[1],alpha=.12)
            ax.plot(mid.delta_e,mid.T10_90,ls,color=COL[1],label=f'r={rate:g}/yr')
        ax.set(title=title,yscale='log',ylim=(150,16000),xlabel='Extra energy need (kcal/person/day)');ax.grid(alpha=.2)
    axs[0].set_ylabel('Replacement time (years)');axs[0].legend(fontsize=8)
    ax=axs[2];ax.scatter(density.delta_e,density.K_M_over_K_N,color=COL[2],label='Model isolated equilibria')
    ax.axhline(10,color=INK,ls='--',label='Disputed reported ratio: ~10')
    ax.set(title='c  Density target not reproduced',xlabel='Extra energy need (kcal/person/day)',ylabel='Population ratio',ylim=(0,11));ax.legend(fontsize=7,loc='upper right')
    fig.suptitle('Historical check: shaded coexistence bands are not fitted targets',fontsize=11)
    data=pd.concat([hist.assign(record_type='replacement'),density.assign(record_type='density')],ignore_index=True)
    save(fig,3,'Historical check of the common mechanism',data,[hp,sp],
         '312 saved replacement records; density ratios from saved isolated equilibria. Lines mu=1/35; shading over mu=1/37,1/35,1/21. No modern calibration.')

    # 4: delivered representative trajectories, with explicitly conditional predictions.
    dp=ROOT/'data/representative_trajectories.csv';d=pd.read_csv(dp);d=d[d.scenario.isin([1,2,3])].copy()
    d['deprivation_years']=10*np.log2(1/d.H_ratio)
    fig,axs=plt.subplots(1,3,figsize=(11,3.4),layout='constrained')
    for sc in (1,2,3):
        x=d[d.scenario==sc]
        for ax,y in zip(axs,('q','deprivation_years','H_ratio')):ax.plot(x.t,x[y],color=COL[sc],label=NAMES[sc])
    for ax,title,ylabel in zip(axs,('a  Adequacy','b  Cumulative deprivation','c  Population'),('q','Deprivation (years)','H / H0 (log scale)')):
        ax.set(title=title,xlabel='Year',ylabel=ylabel);ax.grid(alpha=.2)
    axs[0].set_ylim(-.02,1.03);axs[1].axhline(10,color=INK,ls='--',lw=.8)
    axs[1].text(.02,.96,'Half-population: 10 yr\nQuasi-extinction: 196 yr (off scale)',transform=axs[1].transAxes,va='top',fontsize=8)
    axs[2].set(yscale='log',ylim=(.045,1.1))
    beta=P['e_n']*P['H0']/P['E0_ref'];mu=math.log(2)/10
    s1=d[d.scenario==1];hs=float(s1.loc[np.isclose(s1.t,52),'H_ratio'].iloc[0]);ss=beta*hs
    target=mu*(100-52)+1/ss-math.log(ss)
    predicted=brentq(lambda s:1/s-math.log(s)-target,1e-8,ss)/beta
    s2=d[d.scenario==2];hland=float(s2.loc[np.isclose(s2.t,64.8),'H_ratio'].iloc[0])
    exp_prediction=hland*math.exp(-mu*(100-64.8))
    plateau=brentq(lambda h:.8/h+.2/(1+beta*h)-1,.8,1.)
    for sc,val,name in ((1,predicted,'S1 closed form from year 52'),(2,exp_prediction,'S2 occupied-land exponential from year 64.8'),(3,plateau,'S3 support equilibrium')):
        axs[2].scatter([100],[val],s=60,facecolors='none',edgecolors=COL[sc],zorder=5)
        analytic.append(dict(figure=4,case=name,prediction=val,saved_at_100=float(d[(d.scenario==sc)&np.isclose(d.t,100)].H_ratio.iloc[0]),condition='Conditional saturated subsystem; no fit or empirical calibration. Starting states read from saved samples.'))
    fig.legend(handles=[Line2D([],[],color=COL[s],label=NAMES[s]) for s in (1,2,3)]+[Line2D([],[],ls='',marker='o',markerfacecolor='none',color=INK,label='Reduced-system prediction')],loc='outside lower center',ncol=4,fontsize=8)
    save(fig,4,'Resource adequacy, deprivation and population pathways',d,[dp,ROOT/'config/reference_parameters.json'],
         'Saved time samples, tau_H=10, tau_phys=3, a=0, T=100, h=0.00625. Deprivation is exactly reconstructed as 10*log2(H0/H); circles are labelled reduced-system predictions, not extra simulated observations.')

    # 5: reuse the existing figure's exact source data, preserving stress points.
    scan=[];scanpaths=[]
    for T in (100,200):
        path=R/f'stage4/results_T{T}.json';scanpaths.append(path)
        x=json.loads(path.read_text());scan.extend(dict(scenario=int(sc),T=T,**row) for sc,rs in x['rows'].items() for row in rs)
    scale=pd.DataFrame(scan);fig,axs=plt.subplots(1,2,figsize=(9.4,3.6),sharey=True,layout='constrained')
    for ax,T in zip(axs,(100,200)):
        for sc in (1,2,3,4):
            for stress in (False,True):
                x=scale[(scale['T']==T)&(scale.scenario==sc)&(scale.stress==stress)]
                ax.scatter(x.max_m_run,x.H_ratio_T,marker='x' if stress else ['o','^','s','D'][sc-1],s=12,color=COL[sc],alpha=.6)
        ax.set(title=f'T = {T} years',xscale='log',xlabel='Peak RSI operation / fixed E0',ylim=(-.02,1.03));ax.axhline(.5,color=INK,ls='--',lw=.8);ax.grid(alpha=.2)
    axs[0].set_ylabel('H(T) / H0')
    fig.legend(handles=[Line2D([],[],ls='',marker=['o','^','s','D'][sc-1],color=COL[sc],label=NAMES[sc]) for sc in (1,2,3,4)]+[Line2D([],[],ls='',marker='x',color=INK,label='Response stress values')],loc='outside lower center',ncol=3,fontsize=8)
    save(fig,5,'Population outcomes and extrapolated physical scale',scale,scanpaths,
         'All 2,592 saved fixed-supply horizon records retained; peak operation/E0, E0=31,256 TWh/yr. Scale does not establish feasibility.')

    # 6: no interpolation across categories; every one of 1,968 cells is retained.
    cp=R/'stage5/alignment_curves.csv';tp=R/'stage5/thresholds_refined.csv'
    curves=pd.read_csv(cp);bounds=pd.read_csv(tp)
    atlas=curves[np.isclose(curves.tau_phys,3)&curves.scenario.isin([1,2])].copy()
    assert len(atlas)==1968
    cmap=ListedColormap(['#E7F0EC','#CDA4B5','#3E2335']);norm=BoundaryNorm([-.5,.5,1.5,2.5],3)
    fig,axs=plt.subplots(2,2,figsize=(9.8,7),sharex=True,sharey=True,layout='constrained')
    counts=[]
    for row,T in enumerate((100,200)):
        for col,sc in enumerate((1,2)):
            ax=axs[row,col];g=atlas[(atlas['T']==T)&(atlas.scenario==sc)]
            m=g.assign(code=g.label.map({'normal':0,'marginal':1,'quasi_extinction':2})).pivot(index='tau_H',columns='a',values='code').sort_index().sort_index(axis=1)
            assert m.shape==(12,41) and not m.isna().any().any()
            ax.pcolormesh(edges(m.columns),edges(m.index,True),m.values,cmap=cmap,norm=norm,shading='flat')
            th=np.geomspace(1,220,300);suff=np.maximum(0,1-th/(T-P['W']))
            ax.plot(suff,th,color=INK,lw=1.4)
            ax.axhline(T/math.log2(P['H0']/P['H_ext']),color=INK,ls='--',lw=.9)
            dots=g[(g.label=='normal')&(g.H_ratio_T<.5)];ax.scatter(dots.a,dots.tau_H,s=5,color=INK)
            ref=bounds[(bounds.scenario==sc)&(bounds['T']==T)&np.isclose(bounds.tau_H,10)&np.isclose(bounds.tau_phys,3)].iloc[0]
            ax.scatter([ref.bracket_upper],[10],marker='D',s=40,facecolors='white',edgecolors=INK,zorder=6)
            c=g.label.value_counts().to_dict();counts.append(dict(T=T,scenario=sc,**c,dots=len(dots)))
            ax.set(title=f'{chr(97+row*2+col)}  S{sc}, T={T}; N {c.get("normal",0)}, M {c.get("marginal",0)}, X {c.get("quasi_extinction",0)}',xlim=(-.0125,1.0125),yscale='log',ylim=(.8,250),yticks=[1,2,5,10,20,50,100,200])
            ax.set_yticklabels(['1','2','5','10','20','50','100','200']);ax.yaxis.set_minor_locator(NullLocator())
            if row==1:ax.set_xlabel('Alignment a')
            if col==0:ax.set_ylabel('Response half-life (years)')
            if row==1 and col==1:
                b5=bounds[(bounds.scenario==2)&(bounds['T']==200)&np.isclose(bounds.tau_H,5)&np.isclose(bounds.tau_phys,3)].iloc[0]
                ax.annotate('',xy=(b5.a_grid_safe,5),xytext=(b5.a_grid_avoid_extinction,5),arrowprops=dict(arrowstyle='<->',color=INK,lw=1.2))
                ax.text(.43,1.35,'Avoid X vs avoid M:\n0.300 vs 0.975 (sampled grid)',color=INK,fontsize=8,bbox=dict(facecolor='white',alpha=.9,edgecolor='none',pad=3))
    assert sum(x['dots'] for x in counts)==51
    fig.legend(handles=[Patch(color=cmap(i),label=s) for i,s in enumerate(('N: criterion not met','M: sustained marginalisation','X: quasi-extinction'))]+[Line2D([],[],color=INK,label='Sufficient alignment'),Line2D([],[],color=INK,ls='--',label='No-X bound at a=0'),Line2D([],[],ls='',marker='D',color=INK,label='Refined boundary, half-life 10')],loc='outside lower center',ncol=3,fontsize=8)
    save(fig,6,'Human Fate Atlas',atlas,[cp,tp,ROOT/'config/reference_parameters.json'],
         'tau_phys=3, scenarios 1/2, both horizons; categorical cells without smoothing; N may conceal large losses. Curves are sufficient/necessary analytic bounds, diamonds refined brackets, dots 51 N cells ending below half.')

    # 7: reuse the original distribution-share source and exact Wilson intervals.
    sp=R/'stage7/conditional_shares_audited.csv';d=pd.read_csv(sp);d=d[(d['T']==200)&d.scenario.isin([1,2])].copy()
    fig,axs=plt.subplots(2,2,figsize=(8,5.6),sharex=True,sharey=True,layout='constrained')
    priors=[('P1',COL[1],'o',-.045),('P2',COL[2],'s',0),('P3',COL[3],'^',.045)]
    for row,cat in enumerate(('marginal','quasi_extinction')):
        for col,sc in enumerate((1,2)):
            ax=axs[row,col]
            for pr,color,mk,off in priors:
                g=d[(d.scenario==sc)&(d.category==cat)&(d.prior==pr)].sort_values('a')
                err=np.maximum(0,np.vstack([g.conditional_share-g.wilson95_low,g.wilson95_high-g.conditional_share]))
                ax.errorbar(g.a+off,g.conditional_share,yerr=err,fmt=mk,color=color,ms=5,capsize=3)
            ax.set(title=f'S{sc}: '+('marginalisation' if row==0 else 'quasi-extinction'),xlim=(-.12,1.03),ylim=(-.025,1.025),xticks=[0,.5,.9]);ax.grid(axis='y',alpha=.2)
            if row==1:ax.set_xlabel('Alignment a')
            if col==0:ax.set_ylabel('Conditional scenario share')
    fig.legend(handles=[Line2D([],[],ls='',marker=mk,color=c,label=pr) for pr,c,mk,_ in priors],loc='outside lower center',ncol=3)
    save(fig,7,'Outcome shares conditional on parameter distributions',d,[sp],
         'T=200; S1/S2; P1/P2/P3; 500 paired draws each. Error bars are delivered 95% Wilson intervals for sampling precision, not real-world uncertainty.')

    # 8: keep caps separate and retain even small gains in self-supply cases.
    bp=R/'stage6/branches.csv';wp=R/'stage6/shutdown_weights.csv';b=pd.read_csv(bp);w=pd.read_csv(wp)
    select=lambda x:(x['T']==100)&x.scenario.isin([1,2])&np.isclose(x.tau_H,10)&np.isclose(x.tau_phys,3)&(x.a==0)
    b=b[select(b)].copy();w=w[select(w)&(w.scenario==1)].copy()
    fig=plt.figure(figsize=(9.2,6),layout='constrained');gs=fig.add_gridspec(2,2);axs=[fig.add_subplot(gs[0,0]),fig.add_subplot(gs[0,1]),fig.add_subplot(gs[1,:])]
    handles=[]
    for ax,sc in zip(axs[:2],(1,2)):
        g=b[b.scenario==sc]
        for cap,color,ls in zip((41.5,415,945,3125.6),('#355F8D','#578773','#BA8843','#9D789D'),('-','--','-.',':')):
            x=g[(g.kind=='cap')&np.isclose(g.cap,cap)].sort_values('tau');line,=ax.plot(x.tau,x.H_ratio_T,color=color,ls=ls,label=f'Cap {cap:g} TWh/yr')
            if sc==1:handles.append(line)
        x=g[g.kind=='shutdown_success'].sort_values('tau');line,=ax.plot(x.tau,x.H_ratio_T,color=INK,lw=2,label='Shutdown succeeds')
        if sc==1:handles.append(line)
        ax.axhline(g.baseline_H_ratio.iloc[0],color='#888888',ls=':',lw=1);ax.axhline(.5,color='#888888',ls='--',lw=.7)
        ax.set(title=f'{"a" if sc==1 else "b"}  S{sc}',xlabel='Implementation year',ylabel='Population at year 100 / H0',ylim=(-.02,1.03));ax.grid(alpha=.2)
    for pr,col in ((.5,COL[1]),(.9,COL[2]),(1.,COL[3])):
        x=w[np.isclose(w.p0,pr)].sort_values('tau');axs[2].plot(x.tau,x.weight_normal,color=col,label=f'p0={pr:g}',marker='o',ms=3)
    axs[2].set(title='c  Assumed criterion-avoidance weight',xlabel='Shutdown implementation year',ylabel='Conditional weight',ylim=(-.02,1.03));axs[2].legend(ncol=3);axs[2].grid(alpha=.2)
    fig.legend(handles=handles,loc='outside lower center',ncol=3,fontsize=8)
    save(fig,8,'Intervention timing and assumed execution weights',pd.concat([b.assign(record_type='branch'),w.assign(record_type='weight')],ignore_index=True),[bp,wp],
         'T=100, tau_H=10, tau_phys=3, a=0. Conditional successful shutdown and all four enforced caps. Success weights use assumed p0*(1-I); year 65 is sampled, not an exact or optimised deadline.')

    # 9: actual registered no-intervention matched response comparison, eight pairs.
    rp=ROOT/'supplements/response_form/results/RESPONSE_COMPARISON.csv';d=pd.read_csv(rp);d=d[d.kind=='none'].sort_values(['scenario','a','T']).copy();assert len(d)==8
    fig,ax=plt.subplots(figsize=(8,4.5),layout='constrained');ys=np.arange(len(d))
    for y,(_,row) in zip(ys,d.iterrows()):ax.plot([row.linear_ratio,row.quadratic_ratio],[y,y],color='#BDA6B1',lw=1.6)
    ax.scatter(d.linear_ratio,ys,color=COL[1],label='Linear deficit response',zorder=3)
    ax.scatter(d.quadratic_ratio,ys,color=COL[2],marker='D',label='Quadratic deficit response',zorder=3)
    ax.set_yticks(ys,[f'S{r.scenario}, a={r.a:g}, T={r["T"]:g}' for _,r in d.iterrows()])
    lower=float(min(d.linear_ratio.min(),d.quadratic_ratio.min()))/2
    ax.set(xscale='log',xlabel='Population H(T) / H0 (log scale)',xlim=(lower,1.1));ax.axvline(.5,color=INK,ls='--',lw=.8)
    fig.legend(loc='outside lower center',ncol=2,fontsize=9);ax.grid(axis='x',alpha=.2)
    save(fig,9,'Dependence on the population response form',d,[rp],
         'Only the eight no-intervention pairs; tau_H=10, tau_phys=3, fixed grid, E1. Selected structural contrasts, not a probability sample. Global alignment boundaries were not rerun under the alternative.')

    pd.DataFrame(analytic).to_csv(out/'data/ANALYTIC_MARKERS.csv',index=False)
    (out/'ATLAS_COUNTS.json').write_text(json.dumps(counts,indent=2)+'\n')
    (out/'FIGURE_MANIFEST.json').write_text(json.dumps(dict(model_version='V4',paper_editing_version='v8',mode='replot_delivered_results',new_experiment_trajectories=0,figures=records,input_sha256=sources,script_sha256=sha(Path(__file__)),compiled_reference_sha256=sha(ROOT/'paper/FIGURE_REFERENCE.json'),visual_review='See separate current validation; generation alone does not imply visual acceptance.'),indent=2)+'\n')

if __name__=='__main__':main()
